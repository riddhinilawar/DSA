package search;
public class Binary_descendingsorted {
	public static void main(String args[])
	{

		int a[]= {15,11,7,4,3,1 };
		int key=9;
		int low=0;
		int high=a.length-1;
		while(low<=high)
		{

			int mid=low+(high-low)/2;
			if(a[mid]==key)
			{
				System.out.println("element found");
				return;
			}
			if(a[mid]>key)
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
		}
		System.out.println("element not found");
	}}
