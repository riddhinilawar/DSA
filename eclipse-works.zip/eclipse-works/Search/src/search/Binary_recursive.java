package search;
public class Binary_recursive {
	public static void main(String args[])
	{

		int arr[]= {3 ,3 ,3 ,6 ,6 ,10, 11 };
		int key=20;
		//logic
		System.out.println(binarySearch(arr,key,0,arr.length-1));

	}
	public static boolean binarySearch(int array[], int element, int low, int high) {

		while (low <= high) {

			int mid = low + (high - low) / 2;

			if (array[mid] == element)
				return true;

			if (array[mid] < element)
				low = mid + 1;

			else
				high = mid - 1;
		}

		return false;
	}
}
