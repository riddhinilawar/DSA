package search;
import java.util.*;
public class Linear {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the key");
		int n=sc.nextInt();
		int flag=0;
		int arr[]= {10,20,90,60,6,8,97,65,44};
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]==n)
			flag=1;
		}
		System.out.print("Results:");
		if(flag==1)
			System.out.println("Element found");
		else
			System.out.println("Element not found");
		sc.close();
	}
}
