package search;
public class Binary {
	public static void main(String args[])
	{

		int a[]= {3 ,3 ,3 ,6 ,6 ,10, 11 };
		int key=3;
		int low=0;
		int high=a.length-1;
		while(low<=high)
        {
        
            int mid=low+(high-low)/2;
            if(a[mid]==key)
            {
            	System.out.println("element found");
            	return;
            }
            if(a[mid]<key)
            {
                 low=mid+1;
            }
            else
            {
                high=mid-1;
            }
        }
		System.out.println("element not found");
	}
	
}
