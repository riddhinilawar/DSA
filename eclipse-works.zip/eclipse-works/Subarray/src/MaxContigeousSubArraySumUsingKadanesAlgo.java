import java.util.Scanner;

public class MaxContigeousSubArraySumUsingKadanesAlgo {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		
		int maxsum=Integer.MIN_VALUE;
		int sum=0;
		for(int i=0;i<n;i++)
		{
			sum=sum+arr[i];
			if(sum<0)sum=0;
			maxsum=Math.max(maxsum, sum);
		}
		System.out.println(maxsum);
	}
}
