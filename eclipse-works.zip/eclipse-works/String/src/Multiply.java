import java.util.*;
//gfg multiply two strings
public class Multiply {
	public static void main(String args[])
	{
		
	}
}
