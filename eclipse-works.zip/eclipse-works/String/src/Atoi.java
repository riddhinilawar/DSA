import java.util.*;
//do not use any inbuilt functions.
public class Atoi {
	public static void main(String args[])
	{
		System.out.println(atoi("-12a4"));
	}

	public static int atoi(String str) 
	{
		int num=0;
		if(str.charAt(0)=='-')
		{
			
			for(int i=1;i<str.length();i++)
			{
				if(((int)str.charAt(i)-48)>=0&&((int)str.charAt(i)-48)<=9)
				num=num*10+((int)str.charAt(i)-48);
				else
					return -1;
			}
			return -num;
		}
		else
		{
			
			for(int i=0;i<str.length();i++)
			{
				if(((int)str.charAt(i)-48)>=0&&((int)str.charAt(i)-48)<=9)
				num=num*10+((int)str.charAt(i)-48);
				else
					return -1;
			}
		}
		return num;
	}
}
