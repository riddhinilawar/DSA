import java.util.*;
//tc: O(nlogn)
//word by word
public class LongestCommonPrefix3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String arr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
		}
		sc.close();
		String ans=longestCommonPrefix(arr,arr.length);
		System.out.println(ans);
	}
	public static String longestCommonPrefix(String arr[], int n){
		String ans="";
		int flag=0;
		int min=getmin(arr);
		for(int i=0;i<min;i++)
		{
			char t=arr[0].charAt(i);
			for(int j=1;j<arr.length;j++)
			{
				if(arr[j].charAt(i)!=t)
					{
					flag=1;	
					break;
						
					}
			}
			if(flag==1)break;
			else
			{
				ans=ans+t;
			}
		}
		if(ans.length()==0)return "-1";
		else return ans;
    }
	public static int getmin(String arr[])
	{
		int min=Integer.MAX_VALUE;
		for(int i=0;i<arr.length;i++)
		{
			min=Math.min(min, arr[i].length());
		}
		return min;
	}
	
}
