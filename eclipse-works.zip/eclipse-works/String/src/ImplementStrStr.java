//gfg
//inbuilt funtion not allowed
public class ImplementStrStr {
	public static void main(String args[])
	{
		System.out.println(strstr("GeeksForGeeks","Fr"));
	}
	public static int strstr(String s, String x)
	{
		return 0;
		//for()
	}
}
