//gfg
public class ReverseWordsInAGivenString {
	public static void main(String args[])
	{
		System.out.println(reverseWords("i.like.this.program.very.much"));
	}
	public static String reverseWords(String S)
    {
		String out="";
		String arr[]=S.split("[.]");
		for(int i=arr.length-1;i>0;i--)
		{
			out=out+arr[i]+'.';
		}
		
        return out+arr[0];
    }
}
