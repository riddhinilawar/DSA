import java.util.*;
//tc: O(nlogn)
//sorting
public class LongestCommonPrefix {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String arr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
		}
		sc.close();
		String ans=longestCommonPrefix(arr,arr.length);
		System.out.println(ans);
	}
	public static String longestCommonPrefix(String arr[], int n){
        Arrays.sort(arr);
        String ans="";
        
        int minlen=arr[0].length()>arr[arr.length-1].length()?arr[arr.length-1].length():arr[0].length();
        
        for(int i=0;i<minlen;i++)
        {
            if(arr[0].charAt(i)!=arr[arr.length-1].charAt(i))
            {
                if(i==0)return "-1";
                break;
            }
            else
                ans=ans+arr[0].charAt(i);
        }
        
        return ans;
    }
}
