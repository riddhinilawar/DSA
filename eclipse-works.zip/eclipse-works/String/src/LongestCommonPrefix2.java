import java.util.*;
//tc: O(nlogn)
//char by char
public class LongestCommonPrefix2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String arr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
		}
		sc.close();
		String ans=longestCommonPrefix(arr,arr.length);
		System.out.println(ans);
	}
	public static String longestCommonPrefix(String arr[], int n){
	   String prefix=arr[0];
       for(int i=1;i<n;i++)
       {
    	   prefix=fun(prefix,arr[i]);
       }
       return prefix;
    }
	public static String fun(String s1,String s2)
	{
		String ans="";
		int min=s1.length()>s2.length()?s2.length():s1.length();
		for(int i=0;i<min;i++)
		{
			if(s1.charAt(i)!=s2.charAt(i))
			{
				break;
			}
			else
				ans=ans+s1.charAt(i);
		}
		return ans;
	}
}
