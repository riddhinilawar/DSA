package bNYMellon;
//Q. Given an array of integers, print out an array where at each index i,the total distance from i to every other duplicate element
//of i in the array is shown. For example, if the array was [1,3,1,1,2] the answer would be:[5,0,3,4,0]

//sc:o(n)  //tc:o(nsquare)

import java.util.*;

public class Q1 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun1(arr,n);
	}
	
	//function with O(n square) time complexity
	
	public static void fun(int arr[],int n)
	{
		//putting elements in hashmap
		Hashtable<Integer, ArrayList<Integer>> hash=new Hashtable<>();
		for(int i=0;i<n;i++)
		{
			if(hash.containsKey(arr[i]))
			{
				ArrayList<Integer> temp=hash.get(arr[i]);
				temp.add(i);
				hash.put(arr[i], temp);
			}
			else
			{
				ArrayList<Integer> temp=new ArrayList<Integer>();
				temp.add(i);
				hash.put(arr[i], temp);
			}
		}
		
		//creating ans array and putting all the values in it.
		int ans[]=new int[n];
		for(int i=0;i<n;i++)
		{
			ArrayList<Integer> temp=hash.get(arr[i]);
			int sum=0;
			for(int j=0;j<temp.size();j++)
			{
				sum+=Math.abs(i-temp.get(j));
			}
			ans[i]=sum;
		}
		
		//printing ans
		for(int i: ans)
			System.out.print(i+" ");
	}
	
	//function with O(n) time complexity
	
	public static void fun1(int arr[],int n)
	{
		//putting elements in hashmap
		HashMap<Integer, ArrayList<Integer>> hash=new HashMap<>();
		int ans[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			int sum=0;
			if(hash.containsKey(arr[i]))
			{
				for(int c:hash.get(arr[i]))
				{
					ans[c]+=i-c;
					sum+=i-c;
				}
			}
			ans[i]+=sum;
			hash.putIfAbsent(arr[i], new ArrayList<>());
			hash.get(arr[i]).add(i);
		}
		//System.out.println(hash);
		
		
		
		//printing ans
		for(int i: ans)
			System.out.print(i+" ");
	}
}
