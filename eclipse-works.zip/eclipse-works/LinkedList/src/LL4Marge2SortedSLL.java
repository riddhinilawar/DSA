
public class LL4Marge2SortedSLL {

	public static void main(String args[])
	{
		LL4Marge2SortedSLL l=new LL4Marge2SortedSLL();
		LL4Marge2SortedSLL ll=new LL4Marge2SortedSLL();
		l.add(1);
		l.add(2);
		l.add(4);
		
		
		ll.add(1);
		ll.add(3);
		ll.add(4);
		ll.add(5);


		l.display();
		ll.display();

		LL4Marge2SortedSLL lll=M(l.start,ll.start);
		lll.display();
		
	}
	public static LL4Marge2SortedSLL M(Node start1,Node start2)
	{
		LL4Marge2SortedSLL lll=new LL4Marge2SortedSLL();
		Node head1=start1;
		Node head2=start2;
		while(start1!=null&&start2!=null)
		{
			if(start1.data<start2.data)
			{
				lll.add(start1.data);
				//System.out.println(start1.data+" in  1 ");
				start1=start1.next;
				
			}
			else if(start1.data==start2.data)
			{
				lll.add(start1.data);
				//System.out.println(start1.data+" in  2 ");
				start1=start1.next;
				
				lll.add(start2.data);
				//System.out.println(start2.data+" in  2 ");
				start2=start2.next;
			}
			else
			{
				lll.add(start2.data);
				//System.out.println(start1.data+" in  3 ");
				start2=start2.next;
				
			}
		}
		while(start1!=null)
		{
			lll.add(start1.data);
			start1=start1.next;
		}
		while(start2!=null)
		{
			lll.add(start2.data);
			start2=start2.next;
		}
		return lll;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
