public class LL2MiddleofSLL {
	public static void main(String args[])
	{
		LL2MiddleofSLL l=new LL2MiddleofSLL();
		l.add(0);
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);
		//l.add(5);

		l.display();

		int mid=Middle(l.start);

		System.out.println(mid);
	}
	public static int Middle(Node start)
	{
		Node slow=start;
		Node fast=start;
		
		if(slow==null)
			return 0;
		
		while(fast.next!=null)
		{
			if(fast.next.next==null)break;
			slow=slow.next;
			fast=fast.next.next;
		}
		return slow.data;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
