
public class LL3DeleteNodeInSLL {

	public static void main(String args[])
	{
		LL3DeleteNodeInSLL l=new LL3DeleteNodeInSLL();
		l.add(7);
		l.add(7);
		l.add(4);
		l.add(6);

		l.delete(4);
		l.display();
	}
	
	public void delete(int pos)
	{
		Node temp1=start.next;
		temp=start;
		if(pos==1)
		{
			start=start.next;
		}
		else
		{
			try 
			{
				for(int i=1;i<pos-1;i++)
				{
					temp=temp.next;
					temp1=temp1.next;
				}
				temp.next=temp1.next;
			}
			catch(NullPointerException e)
			{
				System.out.println("Position not found");
			}
		}
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
