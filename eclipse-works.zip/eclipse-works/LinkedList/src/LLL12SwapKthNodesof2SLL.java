public class LLL12SwapKthNodesof2SLL {

	public static void main(String args[])
	{
		LLL12SwapKthNodesof2SLL l=new LLL12SwapKthNodesof2SLL();
		LLL12SwapKthNodesof2SLL ll=new LLL12SwapKthNodesof2SLL();
		l.add(1);
		l.add(2);
		l.add(4);
		
		
		ll.add(7);
		ll.add(3);
		ll.add(9);
		ll.add(5);


		l.display();
		ll.display();

		SwapNode(l.start,ll.start,3);
		
		l.display();
		ll.display();
		
	}
	public static void SwapNode(Node start1,Node start2,int pos)
	{
		Node head1=start1;
		Node head2=start2;
		Node head1prev=null;
		Node head2prev=null;
		int count=1;
		if(pos==1)
		{
			Node head1next=head1.next;
			Node head2next=head2.next;
			head1.next=head2next;
			head2.next=head1next;
			return;
		}
		while(head1!=null&&head2!=null)
		{
			if(pos==count)
			{
				head1prev.next=head2;
				Node t=head2.next;
				head2.next=head1.next;
				head2prev.next=head1;
				head1.next=t;
				break;
			}
			head1prev=head1;
			head1=head1.next;
			head2prev=head2;
			head2=head2.next;
			count++;
		}
		

	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
