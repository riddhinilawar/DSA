public class LLL12SwapKthFirstandLastNodesInSLL {

	public static void main(String args[])
	{
		LLL12SwapKthFirstandLastNodesInSLL l=new LLL12SwapKthFirstandLastNodesInSLL();

		l.add(28);
		l.add(17);
		l.add(25);
		l.add(16);
		l.add(15);
		l.add(12);
		l.add(11);
		l.add(0);

		l.display();
		l.swap(1);
		//edge cases: 1,4.
		l.display();

	}
	public void swap(int pos)
	{
		Node n1=start;
		Node n1prev=null;
		Node n2=start;
		Node n2prev=null;
		Node temp=start;
		int count=1;
		while(temp.next!=null)
		{
			//System.out.println(temp.data+" "+n1.data+" "+n2.data+" "+count);
			count++;
			if(count<=pos)
			{	
				n1prev=n1;
				n1=n1.next;
			}
			else
			{
				n2prev=n2;
				n2=n2.next;
			}
			temp=temp.next;
		}
		System.out.println(n1.data+" "+n2.data);
		if(pos==1)
		{
			Node t=n1;
			n2.next=n1.next;
			n2prev.next=t;
			t.next=null;
			
			start=n2;
		}
		else if(n1.next!=n2)
		{
			n1prev.next=n2;
			Node t=n2.next;
			n2.next=n1.next;
			n2prev.next=n1;
			n1.next=t;
		}
		else
		{
			n1prev.next=n2;
			Node t=n2.next;
			n2.next=n1;
			n1.next=t;
		}
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
