public class LLL13OddEvenSLL {

	public static void main(String args[])
	{
		LLL13OddEvenSLL l=new LLL13OddEvenSLL();
		
		l.add(28);
		l.add(17);
		l.add(25);
		l.add(16);
		l.add(15);
		l.add(12);
		l.add(11);
	
		l.display();
		l.oddeven();
		l.display();

	}
	public void oddeven()
	{
		if(start!=null&&start.next!=null)
		{
			Node odd=start;
			Node even=start.next;
			Node evenhead=even;
			
			while(even!=null&&even.next!=null)
			{
				odd.next=even.next;
				odd=odd.next;
				even.next=odd.next;
				even=even.next;
			}
			odd.next=evenhead;
		}
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
