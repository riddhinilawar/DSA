public class LL5Add2Numbers {
//ll5andll6 are same
	public static void main(String args[])
	{
		LL5Add2Numbers l=new LL5Add2Numbers();
		LL5Add2Numbers ll=new LL5Add2Numbers();
		l.add(7);
		l.add(7);
		l.add(4);
		l.add(6);

		ll.add(5);
		ll.add(6);
		ll.add(4);
		
		l.display();
		ll.display();

		l.reverse();
		ll.reverse();
		
		l.display();
		ll.display();

		LL5Add2Numbers lll=Add(l.start,ll.start);
		lll.display();
		
		lll.reverse();
		lll.display();

	}
	public static LL5Add2Numbers Add(Node start1,Node start2)
	{
		LL5Add2Numbers lll=new LL5Add2Numbers();
		Node head1=start1;
		Node head2=start2;
		int carry=0;
		
		while(start1!=null&&start2!=null)
		{
			if(start1.data+start2.data+carry>=10)
			{
				int temp=start1.data+start2.data+carry-10;
				System.out.println(start1.data+" "+start2.data+" "+carry);
				lll.add(temp);
				start1=start1.next;
				start2=start2.next;
				carry=1;
			}
			else			
			{
				if(carry==1)
				{
					lll.add(start1.data+start2.data+carry);
					carry=0;
				}
				else
				{
				lll.add(start1.data+start2.data);
				}
				System.out.println(start1.data+" "+start2.data+" "+carry);
				start1=start1.next;
				start2=start2.next;
			}
		}
		while(start1!=null)
		{
			if(carry==1)
			{
			lll.add(start1.data+1);
			carry=0;
			}
			else
				lll.add(start1.data);
			start1=start1.next;
		}
		while(start2!=null)
		{
			if(carry==1)
			{
			lll.add(start2.data+1);
			carry=0;
			}
			else
				lll.add(start2.data);
			start2=start2.next;
		}
		return lll;
	}
	public void reverse()
	{
		Node curr=start;
		Node prev=null;
		Node temp;
		
		while(curr!=null)
		{
			temp=curr.next;
			curr.next=prev;
			prev=curr;
			curr=temp;
		}
		start=prev;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
