
public class LL1ReverseSLLUsingRecursion {


	public static void main(String args[])
	{
		LL1ReverseSLLUsingRecursion l=new LL1ReverseSLLUsingRecursion();
		l.add(0);
		l.add(1);
		l.add(2);
		l.add(3);

		l.display();

		l.start=reverse(l.start);

		l.display();
	}
	public static Node reverse(Node start)
	{
		Node prev=start;
		return prev;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
