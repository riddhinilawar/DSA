import java.util.HashSet;

public class LLL11RemoveDuplicatedFromUnSortedList {

	public static void main(String args[])
	{
		LLL11RemoveDuplicatedFromUnSortedList l=new LLL11RemoveDuplicatedFromUnSortedList();
		
		l.add(10);
		l.add(10);
		l.add(11);
		l.add(12);
		l.add(10);
		l.add(12);
		l.add(11);
		l.add(11);
		l.add(11);
	
		l.display();
		l.removedup();
		l.display();

	}
	public void removedup()
	{
		HashSet<Integer> set=new HashSet<>();
		Node curr=start;
		Node prev=null;
		while(curr!=null)
		{
			if(set.isEmpty()==true)
			{
				//System.out.println("in 1"+" "+curr.data+" "+set);
				set.add(curr.data);
				prev=curr;
				curr=curr.next;
			}
			else if(set.contains(curr.data)==true)
			{
				//System.out.println("in 2"+" "+curr.data+" "+set+" "+prev.data);
				prev.next=curr.next;
				curr=curr.next;
			}
			else
			{
				//System.out.println("in 3"+" "+curr.data+" "+set);
				set.add(curr.data);
				prev=curr;
				curr=curr.next;
			}
				
		}
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
