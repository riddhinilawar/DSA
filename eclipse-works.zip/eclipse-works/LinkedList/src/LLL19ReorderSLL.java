public class LLL19ReorderSLL {

	public static void main(String args[])
	{
		LLL19ReorderSLL l=new LLL19ReorderSLL();

		l.add(28);
		l.add(17);
		l.add(25);
		l.add(16);
		l.add(15);
		l.add(12);
		l.add(11);
		l.add(19);
		

		l.display();
		l.reorderlist(l.start);
		//edge cases: 1,4.
		l.display();

	}
	public Node reorderlist(Node head) {
		Node start=head;
		Node last=null;
		int count=0;
		while(start!=null)
		{
			count++;
			last=start;
			start=start.next;
		}
		System.out.println("count="+count+" last="+last.data);

		//Node curr=getlast(head);
		//System.out.println(curr.data);
		//curr=getlast(head);
		//System.out.println(curr.data);


		Node curr=head;
		if(count%2!=0)
		{
		for(int i=0;i<count/2;i++)
		{
			Node n=curr.next;
			last=getlast(head);
			System.out.println(last.data);
			curr.next=last;
			last.next=n;
			curr=n;
		}
		}
		else
		{
			for(int i=0;i<count/2;i++)
			{
				Node n=curr.next;
				if(i==(count/2)-1)n=null;
				last=getlast(head);
				System.out.println(last.data);
				curr.next=last;
				last.next=n;
				curr=n;
			}
		}
		return head;
	}
	public Node getlast(Node head)
	{
		Node start=head;
		Node last=null;
		int count=1;
		while(start.next!=null)
		{
			count++;
			last=start;
			start=start.next;
		}
		last.next=null;
		return start;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
