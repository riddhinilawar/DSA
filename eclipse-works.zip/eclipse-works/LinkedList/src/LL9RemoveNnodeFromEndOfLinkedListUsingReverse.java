public class LL9RemoveNnodeFromEndOfLinkedListUsingReverse {
		public static void main(String args[])
		{
			LL9RemoveNnodeFromEndOfLinkedListUsingReverse l=new LL9RemoveNnodeFromEndOfLinkedListUsingReverse();
			
			l.add(1);
			l.add(4);
			l.add(3);
			l.add(4);
			l.add(1);
			
			l.reverse();
			
			l.RemoveNnode(l.start,4);
			l.reverse();
			l.display();
			
		}
		public void RemoveNnode(Node start1,int pos)
		{
			Node temp1=start.next;
			temp=start;
			if(pos==1)
			{
				start=start.next;
			}
			else
			{
				try 
				{
					for(int i=1;i<pos-1;i++)
					{
						temp=temp.next;
						temp1=temp1.next;
					}
					temp.next=temp1.next;
				}
				catch(NullPointerException e)
				{
					System.out.println("Position not found");
				}
			}
		}
		public void reverse()
		{
			Node curr=start;
			Node prev=null;
			Node temp;
			
			while(curr!=null)
			{
				temp=curr.next;
				curr.next=prev;
				prev=curr;
				curr=temp;
			}
			start=prev;
		}
		//mandatory functions

		Node start;
		Node temp;
		Node last;
		class Node
		{
			int data;
			Node next;
			Node(int data)
			{
				this.data=data;
				this.next=null;
			}
		}
		public void isempty()
		{
			if(start==null)
				System.out.println("List is empty");
			else
				System.out.println("List is not empty");
		}
		public void add(int data)
		{
			Node node=new Node(data);
			if(start==null)
			{
				start=node;
			}
			else
			{
				temp=start;
				while(temp.next!=null)
					temp=temp.next;
				temp.next=node;
			}
			//O(n) complexity
		}
		public void display()
		{
			temp=start;
			while(temp!=null)
			{
				System.out.print(temp.data+" ");
				temp=temp.next;
			}
			System.out.println();
		}

	}
