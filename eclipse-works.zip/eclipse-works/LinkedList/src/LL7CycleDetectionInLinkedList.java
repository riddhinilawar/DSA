public class LL7CycleDetectionInLinkedList {

	public static void main(String args[])
	{
		LL7CycleDetectionInLinkedList l=new LL7CycleDetectionInLinkedList();
		l.add(0);
		l.add(1);
		l.add(2);
		l.add(3);
		l.add(4);

		//l.display();
		
		l.createloop();

		System.out.println(cycledetection(l.start));
		
		//l.display();
	}
	public static boolean cycledetection(Node start)
	{
		Node slow=start;
		Node fast=start;
		while(slow.next!=null&&fast.next!=null&&fast.next.next!=null)
		{
			slow=slow.next;
			fast=fast.next.next;
			if(slow==fast)
			{
				return true;
			}
		}
		return false;
	}
	public void createloop()
	{
		Node curr=start;
		while(curr.next!=null)
		{
			curr=curr.next;
		}
		curr.next=start;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
