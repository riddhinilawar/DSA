public class LLL11RemoveDuplicatedFromSortedList {

	public static void main(String args[])
	{
		LLL11RemoveDuplicatedFromSortedList l=new LLL11RemoveDuplicatedFromSortedList();
		
		l.add(-2);
		l.add(-2);
		l.add(1);
		l.add(2);
		l.add(2);
		l.add(2);
		l.add(4);
		l.add(5);
		l.add(5);
	
		l.display();
		l.removedup();
		l.display();

	}
	public void removedup()
	{
		Node curr=start;
		while(curr.next!=null)
		{
			Node temp=curr.next;
			if(curr.data==curr.next.data);
			{
				curr.next=temp.next;
			}
				curr=curr.next;
		}
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
