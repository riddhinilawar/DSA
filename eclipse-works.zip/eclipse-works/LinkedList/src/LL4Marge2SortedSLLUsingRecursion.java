public class LL4Marge2SortedSLLUsingRecursion {

	public static void main(String args[])
	{
		LL4Marge2SortedSLLUsingRecursion l=new LL4Marge2SortedSLLUsingRecursion();
		LL4Marge2SortedSLLUsingRecursion ll=new LL4Marge2SortedSLLUsingRecursion();
		l.add(1);
		l.add(2);
		l.add(4);


		ll.add(1);
		ll.add(3);
		ll.add(4);
		ll.add(5);


		l.display();
		ll.display();


		Node temp=M(l.start,ll.start);
		LL4Marge2SortedSLLUsingRecursion lll=new LL4Marge2SortedSLLUsingRecursion();
		lll.start=temp;
		lll.display();

	}
	public static Node M(Node start1,Node start2)
	{
		if(start1==null||start2==null)return start1;

		if(start1.data<=start2.data)
		{
			start1.next=M(start1.next,start2);
			//System.out.println(start1.data+" in  1 ");
			return start1;
		}
		else 
		{
			start2.next=M(start1,start2.next);
			//System.out.println(start1.data+" in  1 ");
			return start2;
		}
	}

	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
