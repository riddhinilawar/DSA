public class LL2DeleteMiddleofSLL {

	public static void main(String args[])
	{
		//69 37 72 69 100 84 48 68 87 83, here middle is 84.
		LL2DeleteMiddleofSLL l=new LL2DeleteMiddleofSLL();
		l.add(69);
		l.add(37);
		l.add(72);
		l.add(69);
		l.add(100);
		l.add(84);
		l.add(48);
		l.add(68);
		l.add(87);
		l.add(83);

		l.display();

		LL2DeleteMiddleofSLL.Node temp =Middle(l.start);
		
		l.start=temp;
		
		l.display();
	}
	public static Node Middle(Node head)
	{
		Node slow=head;
		Node fast=head;
		Node prev=null;
		if(slow.next==null)
			return slow.next;
		
		while(fast.next!=null)
		{
			//System.out.println(fast.data+" "+slow.data);
			prev=slow;
			slow=slow.next;
			if(fast.next.next!=null)
				fast=fast.next.next;
			else
				fast=fast.next;
		}
		//System.out.println(slow.data);
		prev.next=slow.next;
		return head;
	}
	//mandatory functions

	Node start;
	Node temp;
	Node last;
	class Node
	{
		int data;
		Node next;
		Node(int data)
		{
			this.data=data;
			this.next=null;
		}
	}
	public void isempty()
	{
		if(start==null)
			System.out.println("List is empty");
		else
			System.out.println("List is not empty");
	}
	public void add(int data)
	{
		Node node=new Node(data);
		if(start==null)
		{
			start=node;
		}
		else
		{
			temp=start;
			while(temp.next!=null)
				temp=temp.next;
			temp.next=node;
		}
		//O(n) complexity
	}
	public void display()
	{
		temp=start;
		while(temp!=null)
		{
			System.out.print(temp.data+" ");
			temp=temp.next;
		}
		System.out.println();
	}

}
