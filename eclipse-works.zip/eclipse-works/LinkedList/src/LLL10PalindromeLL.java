public class LLL10PalindromeLL {
	//ll5andll6 are same
		public static void main(String args[])
		{
			LLL10PalindromeLL l=new LLL10PalindromeLL();
			
			l.add(1);
			l.add(4);
			l.add(3);
			l.add(4);
			l.add(1);
			
			LLL10PalindromeLL ll=new LLL10PalindromeLL();
			ll=l.divide(l.start);
			
			l.display();
			ll.display();
			ll.reverse();
			ll.display();
			System.out.println(isPalindrome(l.start,ll.start));
			
		}
		public LLL10PalindromeLL divide(Node start1)
		{
			Node fast=start.next;
			Node slow=start;
			while(fast.next!=null&&fast.next.next!=null)
			{
				slow=slow.next;
				fast=fast.next.next;
			}
			if(fast.next==null)
			{
				Node temp=slow.next;
				slow.next=null;
				LLL10PalindromeLL ll=new LLL10PalindromeLL();
				ll.start=temp;
				return ll;
			}
			else
			{
				Node temp=slow.next;
				slow.next=null;
				temp=temp.next;
				LLL10PalindromeLL ll=new LLL10PalindromeLL();
				ll.start=temp;
				return ll;
			}
		
		}
		public static boolean isPalindrome(Node start1,Node start2)
		{
			Node head1=start1;
			Node head2=start2;
			while(head1!=null)
			{
				
				if(head1.data!=head2.data)return false;
				head1=head1.next;
				head2=head2.next;
			}
			return true;
		}
		public void reverse()
		{
			Node curr=start;
			Node prev=null;
			Node temp;
			
			while(curr!=null)
			{
				temp=curr.next;
				curr.next=prev;
				prev=curr;
				curr=temp;
			}
			start=prev;
		}
		//mandatory functions

		Node start;
		Node temp;
		Node last;
		class Node
		{
			int data;
			Node next;
			Node(int data)
			{
				this.data=data;
				this.next=null;
			}
		}
		public void isempty()
		{
			if(start==null)
				System.out.println("List is empty");
			else
				System.out.println("List is not empty");
		}
		public void add(int data)
		{
			Node node=new Node(data);
			if(start==null)
			{
				start=node;
			}
			else
			{
				temp=start;
				while(temp.next!=null)
					temp=temp.next;
				temp.next=node;
			}
			//O(n) complexity
		}
		public void display()
		{
			temp=start;
			while(temp!=null)
			{
				System.out.print(temp.data+" ");
				temp=temp.next;
			}
			System.out.println();
		}

	}
