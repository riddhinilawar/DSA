package recursion;

public class Print1ton {
	public static void main(String args[])
	{
		int n=10;
		System.out.println("1 way");
		print(n);
		System.out.println("2 way");
		print(1,n);
	}
	public static void print(int n)
	{
		if(n==1)
		{
			System.out.println(n);
			return;
		}
		else
		{
			print(n-1);//returning to line 9 without printing.
			System.out.println(n);
		}
	}
	public static void print(int m,int n)
	{
		if(m==n)
		{
			System.out.println(m);
			return;
		}
		else
		{
			System.out.println(m);
			print(m+1,n);
		}
	}
}