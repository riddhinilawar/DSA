package recursion;

public class AllSubsets {

}
