package recursion;

public class CountOfZerosInNumber {
	public static void main(String args[])
	{
		int num=102000;
		System.out.println(fun(num,0));
	}
	public static int fun(int num,int count)
	{
		if(num<=0)
		{
			return count;
		}
		else
		{
			if(num%10==0)
				count++;
			return fun(num/10,count);
		}
	}
}