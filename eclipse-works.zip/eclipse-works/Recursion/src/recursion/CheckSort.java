package recursion;

public class CheckSort {
	public static void main(String args[])
	{
		int arr[]= {2,3,4,5,6};
		System.out.println(fun(arr.length-1,arr));
	}
	public static boolean fun(int n,int arr[])
	{
		if(n==1)
			return true;
		else if(arr[n]<arr[n-1])
			return false;
		else
			return fun(n-1,arr);
	}
}
