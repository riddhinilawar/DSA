package recursion;
//inp: aabb
//otp: a*ab*b
//inp: xxxy
//out: x*x*xy
public class PairStar {
	public static void main(String args[])
	{
		String s="xxxy";
		System.out.println(fun(s,0,""));
	}
	public static String fun(String s, int length,String o)
	{
		if(length>=s.length()-1)
		{
			if(s.charAt(length-2)==s.charAt(length-1))
			{
				char temp=s.charAt(s.length()-1);
				return o+'*'+temp;
			}
			else
			{
				char temp=s.charAt(s.length()-1);
				return o+temp;
			}
		}
		else
		{
			if(s.charAt(length)==s.charAt(length+1))
			{
				o=o+s.charAt(length)+"*";
			}
			else
			{
				o=o+s.charAt(length);
			}
			return fun(s,length+1,o);
		}
	}
}
