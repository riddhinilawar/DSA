package recursion;

public class ReplacePi {
	public static void main(String args[])
	{
		String s="pippppiiiipi";
		String str="pip";
		String st="xpix";
		System.out.println(fun(str,0,""));
	}
	public static String fun(String s,int length,String o)
	{	
		if((s.charAt((s.length())-1)=='p')&&(length>=s.length()-1))
		{
			return o+"p";
		}
		else if(length>s.length()-1)
			return o;
		else
		{
			if(s.charAt(length)=='p'&&s.charAt(length+1)=='i')
			{
				o=o+"3.14";
				length++;
			}
			else
			{
				o=o+s.charAt(length);
			}
			return fun(s,length+1,o);
		}
	}
}
