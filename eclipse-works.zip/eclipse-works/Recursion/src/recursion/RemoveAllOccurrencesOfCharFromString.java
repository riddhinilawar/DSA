package recursion;

public class RemoveAllOccurrencesOfCharFromString {
	public static void main(String args[])
	{
		String s="geeksforgeeks";
		char key='e';
		System.out.println(fun(s,0,"",key));
		System.out.println(fun1(s,key));
	}
	public static String fun(String s, int length,String o,char key)
	{
		if(length>=s.length())
			return o;
		else
		{
			if(s.charAt(length)!=key)
			{
			o=o+s.charAt(length);
			}
			
			return fun(s,length+1,o,key);
		}
	}
	public static String fun1(String s,char key)
	{
		if(s.length()==0)
			return s;
		else
		{
			if(s.charAt(0)!=key)
				return s.charAt(0)+fun1(s.substring(1),key);
			else
				return fun1(s.substring(1),key);
		}
	}
}
