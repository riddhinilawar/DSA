package recursion;

public class SumOfArray {
	public static void main(String args[])
	{
		int arr[]= {1,2,3,4,5,6};
		System.out.println(fun(arr,arr.length-1));
	}
	public static int fun(int arr[],int length)
	{
		if(length<0)
			return 0;
		else
		{
			return arr[length]+fun(arr,length-1);
		}
	}
}
