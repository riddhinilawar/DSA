package recursion;

public class Fibonacci {
	public static void main(String args[])
	{
		System.out.println(0);
		System.out.println(1);
		int n=fun(0,1,10);
	}
	public static int fun(int n1,int n2,int n)
	{
		if(n==0)
			return 0;
		else
		{
			int temp=n1;
			n1=n2;
			n2=temp+n1;
			System.out.println(n2);
			return fun(n1,n2,n-1);
		}
	}
}
