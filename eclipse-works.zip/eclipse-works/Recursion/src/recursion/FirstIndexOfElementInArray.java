package recursion;
//inp: 9 8 10 8
//otp: 1
public class FirstIndexOfElementInArray {
	public static void main(String args[])
	{
	int arr[]= {9,8,10,8};
	int key=8;
	System.out.println(fun(arr,0,key));
	}
	public static int fun(int arr[],int length,int key)
	{
		if(length>=arr.length)
		{
			return -1;
		}
		else if(key==arr[length])
		{
			return length;
		}
		else
		{
			return fun(arr,length+1,key);
		}
	}
}
