package recursion;
import java.util.*;
public class CombinationSum {
	public static void main(String[] args) {
		 ArrayList<Integer> A=new ArrayList<Integer>();
		 A.add(2);
		 A.add(5);
		 A.add(6);
		 A.add(7);
		combinationSum(A, 16);
	}
	public static ArrayList<ArrayList<Integer>> combinationSum(ArrayList<Integer> A, int sum)
    {
        ArrayList<Integer> input=new ArrayList<Integer>();
        
        for(int i=0;i<A.size();i++)
            if(!input.contains(A.get(i)))
                input.add(A.get(i));
                
        Collections.sort(input);
        ArrayList<ArrayList<Integer>> ans=new ArrayList<>();
        helper(0,sum,input,ans,new ArrayList<>());
        return ans;
    }
    
    public static void helper(int idx, int sum, ArrayList<Integer> input, ArrayList<ArrayList<Integer>> ans, ArrayList<Integer> output)
    {
        if(idx==input.size())
        {
            if(sum==0)
                if(ans.contains(output)==false)
                    ans.add(new ArrayList<Integer>(output));
            return;
        }
        
        if(input.get(idx)<=sum)
        {
            output.add(input.get(idx));
            System.out.println(idx+" "+(sum-input.get(idx))+" "+input+" ans= "+ans+" output= "+output);
            helper(idx,sum-input.get(idx),input,ans,output);
            output.remove(output.size()-1);
        }
        System.out.println(idx+1+" "+sum+" "+input+" ans= "+ans+" output= "+output);
        helper(idx+1,sum,input,ans,output);
    }
}
