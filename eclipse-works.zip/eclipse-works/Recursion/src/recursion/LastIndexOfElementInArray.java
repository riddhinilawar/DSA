package recursion;
//inp: 9 8 10 8
//otp: 3
public class LastIndexOfElementInArray {
	public static void main(String args[])
	{
	int arr[]= {9,8,10,8};
	int key=8;
	System.out.println(fun(arr,arr.length-1,key));
	}
	public static int fun(int arr[],int length,int key)
	{
		if(length==-1)
		{
			return -1;
		}
		else if(key==arr[length])
		{
			return length;
		}
		else
		{
			return fun(arr,length-1,key);
		}
	}
}
