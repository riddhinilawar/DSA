package recursion;

public class BubbleSort {
	public static void main(String args[])
	{
		int arr[]= {5,4,7,2,9};
		
		arr=sort(arr.length-1,0,arr);
		for(int i=0;i<arr.length;i++)
			System.out.println(arr[i]);
	}
	public static int[] sort(int n,int i,int arr[])
	{
		
		if(arr[i]>arr[i+1])
		{
			return swap(arr,i,i+1);
		}
		else
		{
			return sort(n,i+1,arr);
		}
		
	}
	public static int[] swap(int arr[],int i,int j)
	{
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
		return arr;
	}
}
