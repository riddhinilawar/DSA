package recursion;

public class Add2Numbers {
	public static void main(String args[])
	{
		System.out.println(add(4,5));
	}
	public static int add(int m,int n)
	{
		if(n==0)
			return m;
		else
		{
			
			return add(m,n-1)+1;
			
		}
	}
}
