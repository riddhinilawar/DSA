package recursion;

public class StringToInteger {
	public static void main(String args[])
	{
		String s="12345";
		System.out.println(fun(s,0,0));
	}
	public static int fun(String s, int length,int o)
	{
		if(length>=s.length())
			return o;
		else
		{
		
			char temp=s.charAt(length);
			o=o*10+Character.getNumericValue(temp);
			return fun(s,length+1,o);
		}
	}
}
