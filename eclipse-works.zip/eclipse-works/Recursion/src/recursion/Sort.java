package recursion;
import java.util.*;
public class Sort {
	public static void main(String args[])
	{
		ArrayList<Integer> arr=new ArrayList<>();
		arr.add(2);
		arr.add(7);
		arr.add(1);
		arr.add(9);
		arr.add(3);
		//System.out.println(sort(arr));
	}
//	public static ArrayList<Integer> sort(ArrayList<Integer> arr)
//	{
//		if(arr.size()==1)
//		{
//			return arr;
//		}
//		else
//		{
//			
//			if()
//			{
//				
//			}
//			else
//			{
//				
//			}
//		}
//		return arr;
//	}
}