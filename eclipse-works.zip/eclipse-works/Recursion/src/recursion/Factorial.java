package recursion;

public class Factorial {
	public static void main(String args[])
	{
		System.out.println(fact(10));
	}
	public static int fact(int n)
	{
		int temp=1;
		if(n==0)
			return 1;
		else
		{
			temp=n*fact(n-1);
			return temp;
		}
	}
}
