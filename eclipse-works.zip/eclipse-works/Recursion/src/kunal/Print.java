package kunal;
//print 1 to n numbers
public class Print {
	public static void main(String args[])
	{
		print(1);
	}
	public static void print(int n)
	{
		if(n==5)
		{
			return;
		}
		System.out.println(n);
		print(n+1);
	}
}