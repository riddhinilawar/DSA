package kunal;

public class BinarySearch {
	public static void main(String args[])
	{
		int target=2;
		int arr[]= {7,14,17,18,21,54};
		System.out.println(BS(arr,target));
	}
	public static boolean BS(int arr[],int tar)
	{
		return helper(arr,tar,0,0,arr.length-1);
	}
	public static boolean helper(int arr[],int tar,int mid,int start,int end)
	{
		mid=(start+end)/2;
		System.out.println(mid+ " "+ start+" "+end);
		if(arr[mid]==tar)
			return true;
		else if(start==end&&arr[mid]!=tar) //edge case--if element is not in array
			return false;
		else if(end==-1) //edge case--if element is less than 1st element of the array
			return false;
		else if(start==arr.length) //edge case--if the element is greater than last element of the array
			return false;
		else if(arr[mid]>tar)
			return helper(arr,tar,mid,start,mid-1);
		else
			return helper(arr,tar,mid,mid+1,end);
	}
}
