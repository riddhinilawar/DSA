package kunal;

public class LinearSearch {
	public static void main(String args[])
	{
		int target=9;
		int arr[]= {3,6,7,2,1,9,4};
		System.out.println(LS(arr,target));
	}
	public static boolean LS(int arr[],int tar)
	{
		
		return helper(arr,tar,0);
	}
	public static boolean helper(int arr[],int tar,int index)
	{
		if(index>=arr.length)
			return false;
		else if(arr[index]==tar)
			return true;
		else
			return helper(arr,tar,index+1);
	}
}
