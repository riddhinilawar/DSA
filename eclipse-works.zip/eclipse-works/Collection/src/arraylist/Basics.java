package arraylist;

import java.util.ArrayList;

public class Basics {
	public static void main(String args[])
	{
		ArrayList<Integer> arr=new ArrayList<>();
		arr.add(1);
		arr.add(2);
		arr.add(3);
		arr.add(4);
		System.out.println(arr);
		arr.remove(0);
		System.out.println(arr);
	}
}
