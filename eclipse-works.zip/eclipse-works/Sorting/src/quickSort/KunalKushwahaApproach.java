package quickSort;

public class KunalKushwahaApproach {
	public static void main(String[] args)
	{
		int[] arr = { 2, 1, 6, 10, 4, 1, 3, 9, 7};
		int n = arr.length;
		System.out.println("Sorted array: ");
		quickSort(arr, 0, n - 1);

		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void quickSort(int arr[],int low,int high)
	{
		if(low>high)return;

		int start=low;
		int end=high;
		int mid=low+(high-low)/2;
		int pivot=arr[mid];

		while(start<=end)
		{
			while(arr[start]<pivot)
			{
				start++;
			}
			while(arr[end]>pivot)
			{
				end--;
			}
			if(start<=end)
			{
				int temp=arr[start];
				arr[start]=arr[end];
				arr[end]=temp;
				start++;
				end--;
			}
			
		}
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		quickSort(arr,low,end);
		quickSort(arr,start,high);
	}

}
