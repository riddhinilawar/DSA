package insertionsort;
import java.util.*;

public class StringInsertionSort {
	public static void main(String args[])
	{
		//Taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		String arr[]=new String[n];
		System.out.println("Enter the strings: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
		}
		sc.close();

		//printing unsorted array
		System.out.println("Unsorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		
		//sorting logic for descending
		for(int i=1;i<n;i++)
		{
			for(int j=0;j<i;j++)
			{
				int res=arr[i].compareTo(arr[j]);
				if(res<0)
				{
					String temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
			
			//rounds
//			System.out.println("Round: "+i);
//			for(int k=0;k<n;k++)
//				System.out.print(arr[k]+" ");
//			System.out.println();
		}

		//printing sorted array
		System.out.println("Sorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
}
