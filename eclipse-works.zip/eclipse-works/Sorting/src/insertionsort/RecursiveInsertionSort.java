package insertionsort;
import java.util.*;
public class RecursiveInsertionSort {
	public static void main(String args[])
	{
		//taking input
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		System.out.println("Enter the numbers: ");
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		sc.close();
		
		
		//insertion sort logic
		for(int i=1;i<n;i++)
		{
			for(int j=0;j<i;j++)
			{
				if(arr[i]>arr[j])
				{
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
			
			//rounds
//			System.out.println("Round: "+i);
//			for(int k=0;k<n;k++)
//				System.out.print(arr[k]+" ");
//			System.out.println();
		}
		
		
		//printing the sorted array
		System.out.println("Sorted Array: ");
		for(int i=0;i<n;i++)
			System.out.print(arr[i]+" ");
	}
}
