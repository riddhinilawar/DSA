package bubbleSort;

import java.util.Scanner;

public class BestCaseBubbleSort {
	public static void main(String args[])
	{
		//Taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();

		//printing unsorted array
		System.out.println("Unsorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();

		//sorting logic
		for(int i=0;i<n-1;i++)
		{
			int swaps=0;
			for(int j=0;j<n-1-i;j++)
			{
				if(arr[j]>arr[j+1])
				{
					int temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
					swaps++;
				}
			}
			if(swaps==0&&i==0)
			{
				System.out.println("Array is sorted with best time complexity that is O(n)");
				break;
			}
		}

		//printing sorted array
		System.out.println("Sorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
}
