package bubbleSort;
import java.util.*;

public class StringBubbleSort {
	public static void main(String args[])
	{
		//Taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		String arr[]=new String[n];
		System.out.println("Enter the strings: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.next();
		}
		sc.close();

		//printing unsorted array
		System.out.println("Unsorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
		
		//sorting logic
		for(int i=0;i<n-1;i++)
		{
//			System.out.println("Round "+(i+1));
			for(int j=0;j<n-1-i;j++)
			{
				int res=arr[j].compareTo(arr[j+1]);
				if(res>0?true:false)
				{
					String temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;;
				}
			}
//			for(int k=0;k<n;k++)
//			{
//				System.out.print(arr[k]+" ");
//			}
//			System.out.println();
		}

		//printing sorted array
		System.out.println("Sorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
}
