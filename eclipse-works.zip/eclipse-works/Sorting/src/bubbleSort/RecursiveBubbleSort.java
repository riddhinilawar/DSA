package bubbleSort;

import java.util.Scanner;

public class RecursiveBubbleSort {
	public static void main(String args[])
	{
		//Taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();

		//printing unsorted array
		System.out.println("Unsorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();

		//sorting logic
		BubbleSort(arr, 0);
		//printing sorted array
		System.out.println("Sorted Array:");
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	public static void BubbleSort(int arr[],int index)
	{
		if(index>arr.length-1)
		{
			return;
		}
		for(int i=0;i<arr.length-index-1;i++)
		{
			if(arr[i]>arr[i+1])
			{
				int temp=arr[i];
				arr[i]=arr[i+1];
				arr[i+1]=temp;
			}
		}
		BubbleSort(arr,index+1);
	}
}
