package selectionSort;

import java.util.Scanner;

public class SelectionSortRecursion {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		sc.close();
		int ans[]=SelectionSort(arr,1,0);
		for(int i=0;i<n;i++)
			System.out.print(ans[i]+" ");
	}
	public static int[] SelectionSort(int arr[],int index,int curr)
	{
		if(index>=arr.length-1)
			return arr;
		else
		{
			int min=Integer.MAX_VALUE;
			for(int i=index+1;i<arr.length;i++)
			{
				if(arr[i]<min)min=i;
			}
			int temp=arr[curr];
			arr[curr]=arr[min];
			arr[min]=temp;
			return SelectionSort(arr,index+1,curr+1);
		}
	}
}
