package selectionSort;
import java.util.*;
public class StringSelectionSort {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		String arr[]=new String[n];
		System.out.println("Enter the Strings: ");
		for(int i=0;i<n;i++)
			arr[i]=sc.next();
		sc.close();
		
		//logic
		int min=0;
		for(int i=0;i<n-1;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				int res=arr[i].compareTo(arr[j]);
				if(res>0)
				{
					min=j;
				}
			}
			String temp=arr[i];
			arr[i]=arr[min];
			arr[min]=temp;
		}
		
		//printing sorted array
		System.out.println("sorted array:");
		for(int i=0;i<n;i++)
		System.out.print(arr[i]+" ");
	}
}
