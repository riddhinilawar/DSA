package sort;
import java.util.*;
public class Selection {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the numbers: ");
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		sc.close();
		
		//logic
		for (int i = 0; i < n-1; i++)
        {
            int min_idx = i;
            for (int j = i+1; j < n; j++)
            {
                if (arr[j] < arr[min_idx])
                {
                    min_idx = j;
                }
            }
            int temp = arr[min_idx];
            arr[min_idx] = arr[i];
            arr[i] = temp;
        }
	
		
		//printing sorted array
		System.out.println("sorted array:");
		for(int i=0;i<n;i++)
		System.out.print(arr[i]+" ");
	}
}
