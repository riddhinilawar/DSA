package sort;
import java.util.*;
public class Insertion {
	public static void InsertionSort(int arr[],int index)
	{
		if(index>arr.length-2)
		{
			return;
		}
		for(int j=index+1;j>0;j--)
		{
			if(arr[j-1]>arr[j])
			{
				int temp=arr[j-1];
				arr[j-1]=arr[j];
				arr[j]=temp;
			}
		}
		InsertionSort(arr,index+1);
	}
	public static void main(String args[])
	{
		//taking input
		Scanner sc=new Scanner(System.in);
		System.out.println("Total number of elements to be entered: ");
		int n=sc.nextInt();
		System.out.println("Enter the numbers: ");
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		sc.close();
		
		
		//insertion sort logic
		InsertionSort(arr,0);
		
		//printing the sorted array
		System.out.println("Sorted Array: ");
		for(int i=0;i<n;i++)
			System.out.print(arr[i]+" ");
	}
	
	
}
