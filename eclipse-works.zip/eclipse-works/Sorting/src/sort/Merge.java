package sort;

import java.util.Scanner;

public class Merge {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		mergeSort(arr,0,n-1);
		for(int i=0;i<n;i++)
		{
			System.out.println(arr[i]);
		}
	}
	public static void mergeSort(int arr[], int l, int r)
	{                          
		if(l>=r)return;
		int mid=l+(r-l)/2;
		System.out.println("In 1 start:"+l+" mid:"+mid+" end:"+r);
		mergeSort(arr,l,mid);
		System.out.println("In 2 start:"+l+" mid:"+mid+" end:"+r);
		mergeSort(arr,mid+1,r);
		System.out.println("In 3 start:"+l+" mid:"+mid+" end:"+r);
		merge(arr,l,mid,r);
	}
	public static void merge(int arr[], int start, int mid, int end)
	{
		int index1=start;
		int index2=mid+1;
		int a[]=new int[end-start+1];
		int i=0;
		while(index1<=mid&&index2<=end)
		{
			if(arr[index1]<arr[index2])
			{
				a[i]=arr[index1];
				i++;
				index1++;
			}
			else if(arr[index1]==arr[index2])
			{
				a[i]=arr[index1];
				i++;
				index1++;
				a[i]=arr[index2];
				i++;
				index2++;
			}
			else
			{
				a[i]=arr[index2];
				i++;
				index2++;
			}

		}
		while(index1<=mid)
		{
			a[i]=arr[index1];
			i++;
			index1++;
		}
		while(index2<=end)
		{
			a[i]=arr[index2];
			i++;
			index2++;
		}
		for(int k=0,j=start;k<a.length;k++,j++)
		{
			arr[j]=a[k];
		}
	}

}
