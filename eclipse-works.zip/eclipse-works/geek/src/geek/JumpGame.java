package geek;

public class JumpGame {
	public static void main(String args[])
	{
		int arr[]= {2 ,3 ,1 ,1 ,2 ,4 ,2 ,0 ,1 ,1};
		System.out.println(minJumps(arr));
	}
	static int minJumps(int[] arr){
        int count=0;
        for(int i=0;i<arr.length;i++)
        {
        	if(i!=0)i--;
            if(arr[i]==0)
                return -1;
            else
            {
                int temp=arr[i];
                
                i=i+temp;
               
                count++;
                System.out.println(arr[i]+" "+i+" "+count);
                if(i>=arr.length-1)
                    return count;
            }
        }
        return -1;
    }
}
