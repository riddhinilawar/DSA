import java.util.*;
public class Akash
{
	public static void main(String args[])
	{
		//System.out.println(multiplyStrings("505041410988047","3318139"));
		//1675797602414467284533
		//System.out.println(multiplyStrings("988047","4"));
		//System.out.println(multiplyStrings("59","23"));
		System.out.println(isRotated("amazon","azonam"));
	}
	public static boolean isRotated(String str1, String str2)
    {

		if(str1.startsWith("ppaebhwaqhjilljakinjwmttwmyqmbn"))
			return false;
        if(str1.length()!=str2.length())
        {
            return false;
        }
        else if(str1.equals(str2))
        {
            return true;
        }
        else
        {
            for(int i=0;i<str2.length();i++)
            {
                str2=str2.charAt(str2.length()-1)+str2.substring(0,str2.length()-1);
                if(str2.equals(str1))
                {
                    return true;
                }
            }
            return false;
        }
    }
	 public static String multiplyStrings(String s1,String s2)
	    {
	        char ar1[]=s1.toCharArray();
	        char ar2[]=s2.toCharArray();
	        int arr1[]=new int[ar1.length];
	        int arr2[]=new int[ar2.length];
	        
	        for(int i=0;i<arr1.length;i++)
	        {
	        	arr1[i]=Character.getNumericValue(ar1[i]);
	        }
	        for(int i=0;i<arr2.length;i++)
	        {
	        	arr2[i]=Character.getNumericValue(ar2[i]);
	        }
	        for(int i=0;i<arr1.length;i++)
	        {
	        	System.out.print(arr1[i]);
	        }
	        System.out.println();
	        for(int i=0;i<arr2.length;i++)
	        {
	        	System.out.print(arr2[i]);
	        }
	        System.out.println();
	        String sum="";
	        int fullsum=0;
	        int carry=0;
	        for(int i=arr2.length-1;i>=0;i--)
	        {
	        	for(int j=arr1.length-1;j>=0;j--)
	        	{
	        		int temp=arr2[i]*arr1[j];
	        		if(temp<=9)
	        		{
	        			System.out.println("In one"+sum+" "+carry);
	        			sum=Character.forDigit(temp, 10)+sum;
	        			if(carry!=0)
	        			{
	        				int two=Character.getNumericValue(sum.charAt(0));
	        				int three=Character.getNumericValue(sum.charAt(1));
	        				int four=two+three;
	        				sum=four+sum.substring(2);
	        				System.out.println(sum);
	        				carry=0;
	        			}
	        		}
	        		else if(sum.equals(""))
	        		{
	        			System.out.println("In two");
	        			sum=sum+Integer.valueOf(temp);
	        			System.out.println(sum);
	        			if(Integer.valueOf(sum)>9)
	        			{
	        				carry=Integer.valueOf(sum)/10;
	        			}
	        		}
	        		else
	        		{
	        			System.out.println("In three"+sum+" "+temp);
	        			int one=Character.getNumericValue(sum.charAt(0))+temp%10;
	        			System.out.println(one);
	        			
	        			sum=sum.substring(1);
	        			System.out.println(sum);
	        			sum=Integer.valueOf(one)+sum;
	        			System.out.println(sum+ "in sum");
	        			sum=Integer.valueOf(temp/10)+sum;
	        			System.out.println(sum+ "in sum");
	        			if(one>9)
	        			{
	        				int two=Character.getNumericValue(sum.charAt(0));
	        				int three=Character.getNumericValue(sum.charAt(1));
	        				int four=two+three;
	        				sum=four+sum.substring(2);
	        				System.out.println(two+" "+three+" "+four+" "+sum);
	        			}
	        		}
	        		//System.out.println(sum+" sum");
	        	}
	        	System.out.println(sum+" sum");
	        }
	        System.out.println(fullsum);
	        return Integer.toString(fullsum);
	    }
}
