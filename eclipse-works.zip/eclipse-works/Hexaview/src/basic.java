
public class basic {
	public static void main(String args[])
	
	{
		double d=15/7;
		System.out.println(d);
	}
}
