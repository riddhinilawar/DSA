import java.util.Scanner;
//Time Complexity: O(N*N) to linearly iterate and put it into some other matrix.

//Space Complexity: O(N*N) to copy it into some other matrix.
public class RotateBy90DegreeAntiClockWise {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		rotateby90(matrix, n); 
	}
	public static void rotateby90(int matrix[][], int n) 
	    { 
	        int a[][]=new int[n][n];
	        for(int i=0;i<n;i++)
	        {
	            for(int j=0;j<n;j++)
	            {
	                a[i][j]=matrix[n-1-j][i];
	            }
	        }
	        for(int i=0;i<n;i++)
	        {
	            for(int j=0;j<n;j++)
	            {
	                System.out.print(a[i][j]+" ");
	            }
	            System.out.println();
	        }
	    }
}
