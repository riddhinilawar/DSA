import java.util.*;
//Expected Time Complexity: O(N + M)
//Expected Auxiliary Space: O(1)
public class BoundaryTraversalOfMatrix {
//edge case m=1 n=2
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		int matrix[][]=new int[n][m];

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(boundaryTraversal(matrix, n,m)); 
	}
	public static ArrayList<Integer> boundaryTraversal(int matrix[][], int n, int m)
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
        if(m==1&&n==1)
        {
           
            a.add(matrix[0][0]);
            return a;
        }
        if(m==1)
        {
            
           
             for(int i=0;i<n;i++)
            {
                a.add(matrix[i][0]);
            }
            return a;
        }
        if(n==1)
        {
           
             for(int i=0;i<m;i++)
            {
                a.add(matrix[0][i]);
            }
            return a;
        }
        for(int i=0;i<m;i++)
        {
            a.add(matrix[0][i]);
        }
        for(int i=1;i<n-1;i++)
        {
            a.add(matrix[i][m-1]);
        }
        for(int i=m-1;i>=0;i--)
        {
            a.add(matrix[n-1][i]);
        }
        for(int i=n-2;i>0;i--)
        {
            a.add(matrix[i][0]);
        }
        return a;
    }
	
}
