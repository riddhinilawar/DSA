

import java.util.Scanner;
//TC:O(row*column), SC:O(row+columnn)
public class SetMatrixZero {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		int column=sc.nextInt();
		
		int matrix[][]=new int[row][column];
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		
		//actual logic
		
		int r_arr[]=new int[matrix.length];
        int c_arr[]=new int[matrix[0].length];
        
        for(int i=0;i<matrix.length;i++)
        {
            for(int j=0;j<matrix[0].length;j++)
            {
                if(matrix[i][j]==0)
                {
                    r_arr[i]=-1;
                    c_arr[j]=-1;
                }
            }
        }
        
        for(int i=0;i<matrix.length;i++)
        {
            for(int j=0;j<matrix[0].length;j++)
            {
                if(r_arr[i]==-1||c_arr[j]==-1)
                {
                    matrix[i][j]=0;
                }
            }
        }
		
		//print
        for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
        
		sc.close();
	}
}
