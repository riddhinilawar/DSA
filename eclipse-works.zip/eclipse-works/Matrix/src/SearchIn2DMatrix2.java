

import java.util.Scanner;

public class SearchIn2DMatrix2 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int key=sc.nextInt();
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(search(matrix, n,key)); 
	}
	public static boolean search(int m[][],int n,int key)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(m[i][j]==key)return true;
			}
		}
		return false;
	}
}
