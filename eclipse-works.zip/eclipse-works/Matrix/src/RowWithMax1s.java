import java.util.Scanner;
//Expected Time Complexity: O(N+M)
//Expected Auxiliary Space: O(1)
public class RowWithMax1s {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		
	}
	
}
