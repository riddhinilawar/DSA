import java.util.*;
//TC:-O(n*n)   SC:-O(1)
public class TransposeOfMatrix2 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		//logic
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				int temp=matrix[i][j];
				matrix[i][j]=matrix[j][i];
				matrix[j][i]=temp;
			}
		}
		//print
        for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
	}
}
