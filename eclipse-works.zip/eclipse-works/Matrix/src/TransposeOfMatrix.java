import java.util.*;
//TC:-O(n*n)   SC:-O(n*n)
public class TransposeOfMatrix {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		
		//logic
		
		int temp[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				temp[i][j]=matrix[j][i];
			}
			
		}
		
		//print
        for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				System.out.print(temp[i][j]+" ");
			}
			System.out.println();
		}
	}
}
