import java.util.Scanner;
//Expected Time Complexity: O(N*M)
//Expected Auxiliary Space: O(1)
public class PredictTheColumn {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(columnWithMaxZeros(matrix, n)); 
	}
	public static int columnWithMaxZeros(int arr[][], int N)
    {
        int max=0,ans=0;
        for(int j=0;j<arr[0].length;j++)
        {
            int count=0;
            for(int i=0;i<arr.length;i++)
            {
                if(arr[i][j]==0)
                count++;
            }
            if(count>max)
            {
                max=count;
                ans=j;
            }
        }
        return ans;
    }
}
