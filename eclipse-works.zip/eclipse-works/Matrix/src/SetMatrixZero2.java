
//TC:O(row*column), SC:O(1)
import java.util.Scanner;

public class SetMatrixZero2 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int row=sc.nextInt();
		int column=sc.nextInt();
		
		int matrix[][]=new int[row][column];
		
		for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		
		//actual logic
		int col0=0;
		for(int i=0;i<row;i++)
		{
			if(matrix[i][0]==1)
				col0=1;
			for(int j=1;j<column;j++)
			{
				if(matrix[i][j]==1)
				{
					matrix[i][0]=1;
					matrix[0][j]=1;
				}
			}
		}
		
		for(int i=row-1;i>=0;i--)
		{
			for(int j=column-1;j>=1;j--)
			{
				if(matrix[i][0]==1||matrix[0][j]==1)
				{
					matrix[i][j]=1;
				}
			}
			if(col0==1)matrix[i][0]=1;
		}
		
		
		//print
        for(int i=0;i<row;i++)
		{
			for(int j=0;j<column;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
        
		sc.close();
	}
}
