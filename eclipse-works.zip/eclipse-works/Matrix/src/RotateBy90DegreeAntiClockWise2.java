import java.util.Scanner;
//Time Complexity: O(N*N) to linearly iterate and put it into some other matrix.

//Space Complexity: O(N*N) to copy it into some other matrix.
public class RotateBy90DegreeAntiClockWise2 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();

		int matrix[][]=new int[n][n];

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		rotateby90(matrix, n); 
	}
	public static void rotateby90(int matrix[][], int n) 
	{ 
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				int temp=matrix[i][j];
				matrix[i][j]=matrix[j][i];
				matrix[j][i]=temp;
			}
		}
		
		for(int j=0;j<(n/2);j++)
		{
			for(int i=0;i<n;i++)
			{
				//System.out.println(i+" "+j+" "+i+" "+(n-1-j));
				int temp=matrix[i][j];
				matrix[i][j]=matrix[i][n-1-j];
				matrix[i][n-1-j]=temp;
			}
		}
		
		
		//print
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
	}
}
