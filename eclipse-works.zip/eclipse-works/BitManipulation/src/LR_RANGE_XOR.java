
public class LR_RANGE_XOR {
	public static void main(String args[])
	{
		System.out.println(leftToRightRange(6,6));
	}
	public static int leftToRightRange(int l,int r)
	{
		if(l==0||l==1) return NRange(r);
		else return (NRange(r)^NRange(l-1));
	}
	public static int NRange(int n)
	{
		if(n%4==0) return n;
		else if(n%4==1) return 1;
		else if(n%4==2) return n+1;
		else return 0;
		
	}
}
