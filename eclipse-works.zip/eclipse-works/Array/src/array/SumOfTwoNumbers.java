package array;
//correct but time complexity is more
public class SumOfTwoNumbers {
	public static void main(String args[])
	{
		String X="0";
		String Y="0";
	
		String ans="";
		int carry=0;

		//reversing

		String XX="";
		char ch;

		for (int i=0; i<X.length(); i++)
		{
			ch= X.charAt(i); 
			XX= ch+XX;
		}
		//System.out.println(XX);
		String YY="";

		for (int i=0; i<Y.length(); i++)
		{
			ch= Y.charAt(i); 
			YY= ch+YY;
		}
		//System.out.println(YY);
		//main logic

		int flength=XX.length();
		int slength=YY.length();

		int i=0;

		while(i<flength&&i<slength)
		{
			int first=Character.getNumericValue(XX.charAt(i));
			//System.out.println("first--"+first);
			int second=Character.getNumericValue(YY.charAt(i));
			//System.out.println("second--"+second);
			if(first+second<10&&carry==0)
			{
				int temp=first+second;
				ans=ans+temp;
				//System.out.println(" in 1");
			}
			else if(first+second+carry<10&&carry==1)
			{

				int temp=first+second+carry;
				ans=ans+temp;
				//System.out.println(" in 2");
				carry=0;
			}
			else if(first+second>9&&carry==0)
			{
				int temp=first+second;
				ans=ans+(temp%10);
				carry=1;
				//System.out.println(" in 3");
			}
			else if(first+second+carry>9&&carry==1)
			{
				int temp=first+second+carry;
				ans=ans+(temp%10);
				carry=1;
				//System.out.println(" in 4");
			}
			i++;
		}
		while(i<flength)
		{
			if(carry==1)
			{
				int first=Character.getNumericValue(XX.charAt(i));
				int temp=first+carry;
				if(temp>9)
				{
					carry=1;
					ans=ans+(temp%10);
				}
				else
				{
					carry=0;
					ans=ans+temp;
				}
				i++;
				
			}
			else
			{
				int first=Character.getNumericValue(XX.charAt(i));
				ans=ans+first;
				i++;
			}
		}
		while(i<slength)
		{
			if(carry==1)
			{
				int second=Character.getNumericValue(YY.charAt(i));
				int temp=second+carry;
				if(temp>9)
				{
					carry=1;
					ans=ans+(temp%10);
				}
				else
				{
					carry=0;
					ans=ans+temp;
				}
				i++;
			}
			else
			{
				int second=Character.getNumericValue(YY.charAt(i));
				ans=ans+second;
				i++;
			}
		}
		if(carry==1)ans=ans+"1";
		//System.out.println(ans);

		//reversing

		String a="";

		for (int j=0; j<ans.length(); j++)
		{
			ch= ans.charAt(j); 
			a= ch+a;
		}
		if (a.equals("0"))
			{
				a= "0";
				System.out.println(a);
				return;
			}
		while(a.charAt(0)=='0')
		{
			a=a.substring(1);
			if(a.length()==1)break;
		}
		System.out.println(a);
	}
}
