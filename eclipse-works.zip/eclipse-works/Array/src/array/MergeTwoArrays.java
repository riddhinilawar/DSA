package array;
import java.util.*;
public class MergeTwoArrays {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of elements you wanted to enter in first array");
		int n=sc.nextInt();
		int arr1[]=new int[n];
		System.out.println("Enter the elements");
		for(int i=0;i<n;i++)
			arr1[i]=sc.nextInt();
		
		System.out.println("Enter the number of elements you wanted to enter in second array");
		int m=sc.nextInt();
		int arr2[]=new int[m];
		System.out.println("Enter the elements");
		for(int i=0;i<m;i++)
			arr2[i]=sc.nextInt();
		sc.close();
		
		
		//logic
		int i=0,j=0,k=0;
		int res[]=new int[n+m];
		
		for(int z=0;z<(m+n);z++)
		{
			System.out.println("z:"+z);
			if(arr1[i]<arr2[j])
			{
				res[k]=arr1[i];
				//System.out.println(res[k]);
				i++;
				k++;
			}
			else if(arr1[i]==arr2[j])
			{
				res[k]=arr1[i];
				//System.out.println(res[k]);
				res[k]=arr2[j];
				//System.out.println(res[k]);
				i++;
				j++;
				k++;
			}
			else if(arr1[i]>arr2[j])
			{
				res[k]=arr2[j];
				//System.out.println(res[k]);
				j++;
				k++;
			}
			if(i==n)
			{
				//System.out.println("In i full");
				for(int x=j;x<m;x++)
				{
					res[k]=arr2[j];
					//System.out.println(res[k]);
					j++;
					k++;
				}
				break;
			}
			else if(j==m)
			{
				//System.out.println("In j full");
				for(int x=i;x<n;x++)
				{
					res[k]=arr1[i];
					//System.out.println(res[k]);
					i++;
					k++;
				}
				break;
			}
		}
		
		//printing output
		System.out.println("Merged array");
		for(int l=0;l<m+n;l++)
			System.out.println(res[l]+" ");
	}
}
