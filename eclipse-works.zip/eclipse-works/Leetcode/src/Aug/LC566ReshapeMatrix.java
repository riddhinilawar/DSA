package Aug;

import java.util.Scanner;

public class LC566ReshapeMatrix {
	public static void main(String[] args) {
		//taking inputs
				Scanner sc=new Scanner(System.in);
				int r=sc.nextInt();
				int c=sc.nextInt();

				int m[][]=new int[r][c];

				for(int i=0;i<r;i++)
				{
					for(int j=0;j<c;j++)
					{
						m[i][j]=sc.nextInt();
					}
				}

				int rr=sc.nextInt();
				int cc=sc.nextInt();
				
				int mat[][]=matrixReshape(m,rr,cc);
				
				for(int i=0;i<rr;i++)
				{
					for(int j=0;j<cc;j++)
					{
						System.out.print(mat[i][j]);
					}
					System.out.println();
				}
	}
	 public static int[][] matrixReshape(int[][] mat, int r, int c) {
	        int n=mat.length;
	        int m=mat[0].length;
	        
	        if(n==r&&m==c)return mat;
	        else
	        {
	            int matrix[][]=new int[r][c];
	            int count=0;
	            for(int i=0;i<n;i++)
	            {
	                for(int j=0;j<m;j++)
	                {
	                    matrix[count/c][count%c]=mat[i][j];
	                    count++;
	                }
	            }
	            
	            return matrix;
	        }
	    }
}
