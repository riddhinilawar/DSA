package Aug;

import java.util.Scanner;

public class LC1752_checkIfArrayIsSortedOrRotated {
	public class LC125Palindrome {

	}
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(sortrotate(arr));
	}
    public static boolean sortrotate(int[] nums) {
        int c=0;
         for(int i = 0; i < nums.length; i++){
            if(nums[i] > nums[(i+1)%nums.length]){
                c++;
            }
        }
         System.out.println(c);
        return c > 1 ? false : true;
    }

}
