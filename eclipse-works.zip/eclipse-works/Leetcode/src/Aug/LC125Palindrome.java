package Aug;

public class LC125Palindrome {
	public static void main(String[] args) {
		System.out.println(isPalindrome("Sore was I ere I saw Eros."));
	}
	public static boolean isPalindrome(String s) {
        int n=s.length();
        int i=0,j=s.length()-1;
        int c=0;
        while(i<j)
        {
            while((s.charAt(i)<65||s.charAt(i)>90)&&(s.charAt(i)<97||s.charAt(i)>122)&&     (s.charAt(i)<48||s.charAt(i)>57))
            {
                i++;
                c++;
                if(c==n)return true;
            }
             while((s.charAt(j)<65||s.charAt(j)>90)&&(s.charAt(j)<97||s.charAt(j)>122)&&     (s.charAt(j)<48||s.charAt(j)>57))
            {
                j--;
            }
            
            char ii=s.charAt(i);
            char jj=s.charAt(j);
            System.out.println(s.charAt(i)+" "+s.charAt(j)+" "+i+" "+j);
            
            if((s.charAt(i)>=65&&s.charAt(i)<=90)&&(s.charAt(j)>=65&&s.charAt(j)<=90))
            {
                System.out.println(1);
                if(ii!=jj)
                {
                    System.out.println("f1");
                    return false;
                }
            }
            else if((s.charAt(i)>=65&&s.charAt(i)<=90))
            {
                System.out.println(2);
                if(ii!=(jj-32))
                {
                    System.out.println("f2");
                    return false;
                }
            }
            else if((s.charAt(j)>=65&&s.charAt(j)<=90))
            {
                System.out.println(3);
                if((ii-32)!=jj)
                {
                    System.out.println("f3");
                    return false;
                }
            }
            else 
            {
                System.out.println(4);
               if(ii!=jj)
               {
                     System.out.println("f4");
                   return false;
               }
            }
            
            i++;
            j--;
        }
        return true;
    }
}
