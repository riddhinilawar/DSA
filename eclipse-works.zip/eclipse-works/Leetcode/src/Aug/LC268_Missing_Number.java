package Aug;

import java.util.Scanner;

public class LC268_Missing_Number {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(missingNumber(arr));
	}
    public static int missingNumber(int[] a) {
        int sum=0;
        int n=a.length;
        for(int i=0;i<a.length;i++)
        {
            sum=sum+a[i];
        }
        
        int d_sum=n*(n+1);
        d_sum=d_sum/2;
        
        return d_sum-sum;
    }
}
