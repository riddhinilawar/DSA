package Aug;

public class LC59SpiralMatrix2 {
	public static void main(String[] args) {
		int ans[][]=generateMatrix(3);
		for(int i=0;i<ans.length;i++)
		{
			for(int j=0;j<ans[0].length;j++)
			{
				System.out.print(ans[i][j]+" ");
			}
			System.out.println();
		}
	}
	 public static int[][] generateMatrix(int n) {
	        int counter=1;
	        int ans[][]=new int[n][n];
	        int top=0,right=n-1,bottom=n-1,left=0;
	        while(counter<=(n*n))
	        {
	            for(int i=left;i<=right;i++)
	            {
	                ans[top][i]=counter;
	                counter++;
	            }
	            top++;
	            
	            for(int i=top;i<=bottom;i++)
	            {
	                ans[i][right]=counter;
	                counter++;
	            }
	            right--;
	            
	            for(int i=right;i>=left;i--)
	            {
	                ans[bottom][i]=counter;
	                counter++;
	            }
	            bottom--;
	            
	            for(int i=bottom;i>=top;i--)
	            {
	                ans[i][left]=counter;
	                counter++;
	            }
	            left++;
	        }
	        return ans;
	    }
}
