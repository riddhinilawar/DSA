package Aug;
//code is correct but time limit exceeded
import java.util.ArrayList;

	public class LC885SpiralMatrix3 {
	public static void main(String[] args) {
		int ans[][]=spiralMatrixIII(5,6,1,4);
		for(int i=0;i<ans.length;i++)
		{
			for(int j=0;j<ans[0].length;j++)
			{
				System.out.print(ans[i][j]+" ");
			}
			System.out.println();
		}
	}
	public static int[][] spiralMatrixIII(int rows, int cols, int rStart, int cStart) 
	{
	        int counter=1;
	        ArrayList<int[]> ans=new ArrayList<>();
	        ans.add(new int[]{rStart,cStart});
	        
	        //while(rStart>=(-rows)&&cStart>=(-cols)&&rStart<=(2*rows)&&cStart<=(2*cols))
	        while(rStart<rows||cStart<cols)
	        {
	            for(int i=0;i<counter;i++)
	            {
	                cStart++;
	                if(rStart>=0&&cStart>=0&&rStart<rows&&cStart<cols)
	                ans.add(new int[]{rStart,cStart});
	                //System.out.println(rStart+" "+cStart);
	            }
	           
	            
	            for(int i=0;i<counter;i++)
	            {
	            	 rStart++;
	            	 if(rStart>=0&&cStart>=0&&rStart<rows&&cStart<cols)
	            	 	ans.add(new int[]{rStart,cStart});
		                //System.out.println(rStart+" "+cStart);
	            }
	          
	            counter++;
	            
	            for(int i=0;i<counter;i++)
	            {
	                cStart--;
	                if(rStart>=0&&cStart>=0&&rStart<rows&&cStart<cols)
	                ans.add(new int[]{rStart,cStart});
	                //System.out.println(rStart+" "+cStart);
	            }
	           
	            
	            for(int i=0;i<counter;i++)
	            {
	            	 rStart--;
	            	 if(rStart>=0&&cStart>=0&&rStart<rows&&cStart<cols)
	            	    ans.add(new int[]{rStart,cStart});
		                //System.out.println(rStart+" "+cStart);
	            }
	            
	            counter++;
	            
	        }
	        return ans.toArray(new int[0][]);
	    }
}
