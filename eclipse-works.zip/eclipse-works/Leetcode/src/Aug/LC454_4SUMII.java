package Aug;
import java.util.*;
public class LC454_4SUMII {
	  public static int fourSumCount(int[] nums1, int[] nums2, int[] nums3, int[] nums4) {
		  List<List<Integer>> list=new ArrayList<>();
	        
	        Arrays.sort(nums4);
	        
	        for(int i=0;i<nums1.length;i++)
	        {
	            
	            for(int j=0;j<nums2.length;j++)
	            {
	                 for(int k=0;k<nums3.length;k++)
	                 {
	                
	                List<Integer> ll=new ArrayList<Integer>();
	                
	                int t=(0-nums1[i]-nums2[j]-nums3[k]);
	                     
	                long exc=(long)nums1[i]+(long)nums2[j]+(long)nums3[k];
	                
	                if(exc>Integer.MAX_VALUE||exc<Integer.MIN_VALUE)continue;
	                
	                if(BS(nums4,0,nums4.length-1,t)==true)
	                {
	                	System.out.println(i+" "+j+" "+k+"-------------"+nums1[i]+" "+nums2[j]+" "+nums3[k]+" "+t);
	                    ll.add(nums1[i]);
	                    ll.add(nums2[j]);
	                    ll.add(nums3[k]);
	                    ll.add(t);
	                    list.add(ll);
	                }
	                else
	                {
	                	System.out.println("not in "+i+" "+j+" "+k+"-------------"+nums1[i]+" "+nums2[j]+" "+nums3[k]+" "+t);
	                }
	                   
	                 }
	            }
	        }
	        System.out.println(list);
		    return list.size();
	     
	    }
	    public static boolean BS(int nums[],int start,int end,int target)
	    {
	        while(start<=end)
	        {
	             int mid=start+(end-start)/2;
	            
	             if(nums[mid]==target)return true;
	            
	             if(nums[mid]>target) return BS(nums,start,mid-1,target);
	             else return BS(nums,mid+1,end,target);
	        }
	        return false;
	    }
	    public static void main(String args[])
	    {
	    	
	    	/*int a[]={1,2};
	    	int b[]= {-2,-1};
	    	int c[]= {-1,2};
	    	int d[]= {0,2};*/
	    	/*int a[]={-1,-1};
	    	int b[]= {-1,1};
	    	int c[]= {-1,1};
	    	int d[]= {1,-1};*/
	    	int a[]={0,1,-1};
	    	int b[]= {-1,1,0};
	    	int c[]= {0,0,1};
	    	int d[]= {-1,1,1};
	    	System.out.println(fourSumCount(a,b,c,d));
	    }
	}

