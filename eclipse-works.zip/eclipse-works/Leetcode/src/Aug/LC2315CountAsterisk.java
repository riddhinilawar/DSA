package Aug;

import java.util.Scanner;

public class LC2315CountAsterisk {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println(countAsterisks(sc.next()));
		sc.close();
	}
	 public static  int countAsterisks(String s) {
	        boolean flag=true;
	        int count=0;
	        for(int i=0;i<s.length();i++)
	        {
	            if(s.charAt(i)=='|'&&flag==true)
	            {
	                flag=false;
	            }
	            else if(s.charAt(i)=='|'&&flag==false)
	            {
	                flag=true;
	            }
	            
	            if(flag==true)
	            {
	                if(s.charAt(i)=='*')
	                count++;
	            }
	        }
	        return count;
	    }
}
