package dsa;

public class Tree {
	Node root;
	class Node
	{
		int data;
		Node lref=null;
		Node rref=null;
		
		Node(int data)
		{
			this.data=data;
		}
	}
	
	public static void main(String args[])
	{
		
	}
}
