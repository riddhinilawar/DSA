package gfg;

import java.util.*;
/*
1*2*3*10*11*12
--4*5*8*9
----6*7

 */
public class PrintThePattern1 {
	public static void main(String[] args) {
		pattern(3);
	}
	public static List<String> pattern(int n){
		ArrayList<String> a=new ArrayList<>();
		int c=(n*2);
		int cc=c-1;
		c=c+cc;
		int tt=c/2;
		int left=1;
		int right=(n*(n+1))/2;
		
		for(int i=0;i<n;i++)
		{
			
			//for right
			int m=n-1-i;
			int rightrow=(m*(m+1))/2;
			int r=right+rightrow+1;
			
			for(int j=0;j<c;j++)
			{	
			if(j<(2*i))
			{
				System.out.print("-");
			}
			else if(j>((2*(tt)-(2*i))))
			{
				
			}
			else
			{
				if(j%2!=0)
					System.out.print("*");
				else 
				{
					if(j<tt)
					{
						System.out.print(left);
						left++;
					}
					else
					{
						System.out.print(r);
						r++;
					}
				}
			}
			}
			System.out.println();
		}
		a.add("hi");
		return a;
	}
}
