import java.util.*;
public class ValidStackSequence {

	public boolean validateStackSequences(int[] pushed, int[] popped) {

		Stack<Integer> stack = new Stack<>();
		int pushidx=0;
		int popidx=0;

		while(pushidx<pushed.length){
			stack.push(pushed[pushidx]);
			pushidx++;
			while(popidx<popped.length && !stack.isEmpty() &&  popped[popidx] == stack.peek()){
				stack.pop();
				popidx++;
			}
		}

		if(stack.isEmpty())
			return true;
		return false;
	}

}
