import java.util.Stack;

public class AsteroidCollision {
	public static void main(String args[])
	{
		int arr[]={-5,5,10,-5};// {10,6,-8,-8,8,9};
		Stack<Integer> s=new Stack<Integer>();

		for(int i=0;i<arr.length;i++)
		{
			int curr=arr[i];
			if(s.isEmpty()==false)
			{
				if(-(curr)==s.peek())
				{
					s.pop();

				}
				else if(curr>0 && s.peek()>0)
				{
					s.push(curr);

				}
				else if(curr<0 && s.peek()<0)
				{
					s.push(curr);

				}
				else
				{
					int curr1=Math.abs(curr);
					int	temp1=Math.abs(s.peek());

					if(curr1>temp1)
					{
						s.pop();
						i--;
					}

				}
			}
			else
			{
				s.push(curr);

			}
		}

		System.out.println(s);
	}
}
