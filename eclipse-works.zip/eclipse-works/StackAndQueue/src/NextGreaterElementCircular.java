import java.util.ArrayList;
import java.util.Collections;
import java.util.Stack;

public class NextGreaterElementCircular {
	public static void main(String args[])
	{
		//int arr[]= {4,12,5,3,1,2,5,3,1,2,4,6};
		int arr[]= {2,10,12,1,11,2,10,12,1,11};
		Stack<Integer> s=new Stack<Integer>();
		ArrayList a=new ArrayList<>();
		
		for(int i=0;i<=(2*arr.length)-1;i++)
		{
			while(!s.isEmpty()&&s.peek()<=arr[i%arr.length])
				s.pop();
			if(i<arr.length)
			{
				if(s.isEmpty()==true)
					a.add(-1);
				else
					a.add(s.peek());
			}
			s.push(arr[i%arr.length]);
		}
		Collections.reverse(a);
		System.out.println(a);
		
	}
}
