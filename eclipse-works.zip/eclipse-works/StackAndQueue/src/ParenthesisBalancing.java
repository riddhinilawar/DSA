import java.util.*;
//gfg
public class ParenthesisBalancing {
	public static void main(String args[])
	{
		System.out.println("[(]");
	}
	public  static boolean ispar(String x)
		{
			if(x.length()<2)
				return false;
			if(x.length()%2!=0)
				return false;
			Stack s=new Stack<Character>();
			for(int i=0;i<x.length();i++)
			{
				char c=x.charAt(i);
				if(c=='('||c=='{'||c=='[')
				{
					s.push(c);
				}
				else if(c==')')
				{
					if(s.isEmpty()==false)
					{
					if((s.peek().toString().charAt(0))=='(')
						s.pop();
					else
						return false;
					}
					else
						return false;
				}
				else if(c==']')
				{
					if(s.isEmpty()==false)
					{
					if((s.peek().toString().charAt(0))=='[')
						s.pop();
					else
						return false;
					}
					else
						return false;
				}
				else if(c=='}')
				{
					if(s.isEmpty()==false)
					{
					if((s.peek().toString().charAt(0))=='{')
						s.pop();
					else
						return false;
					}
					else
						return false;
				}
			}
			if(s.isEmpty())
				return true;
			else
				return false;
		}
}
