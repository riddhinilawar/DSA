import java.util.*;
//gfg
public class Reverse {
	public static void main(String args[])
	{
		System.out.println(reverse("Riddhi"));
	}
	public static String reverse(String S){
	       
        Stack s=new Stack<Character>();
        for(int i=0;i<S.length();i++)
        {
            s.push(S.charAt(i));
        }
        String output="";
         for(int i=0;i<S.length();i++)
        {
            output=output+s.pop();
        }
        return output;
}
}
