import java.util.*;

public class NumberOfNEGsToRight {
	public static void main(String[] args) {
		int arr[]= {4,12,5,3,1,2,5,3,1,2,4,6};
		Stack<Integer> s=new Stack<Integer>();
		ArrayList a=new ArrayList<>();
		for(int i=0;i<arr.length;i++)
		{
			if(s.isEmpty()==true)
			{
				s.push(arr[i]);
				a.add(-1);
			}
			else
			{
				if(arr[i]<s.peek())
				{
					a.add(s.peek());
					s.push(arr[i]);
				}
				else if(arr[i]>s.peek())
				{
					while(s.isEmpty()==false)
					{
						if(arr[i]<s.peek())
						{
							break;
						}
						s.pop();
					}
					if(s.isEmpty()==false)a.add(s.peek());else a.add(-1);
					s.push(arr[i]);
				}
			}
		}
		
		System.out.println(a);
	}
}
