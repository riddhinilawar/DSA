package day3;

import java.util.Scanner;

public class SearchIn2DMatrix3 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		int key=sc.nextInt();
		int matrix[][]=new int[n][m];

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(matSearch(matrix, n,m,key)); 
	}
	public static int matSearch(int mat[][], int N, int M, int X)
    {
       int i=0,j=M-1;
       int temp=mat[i][j];
       
       try
       {
            while(true)
            {
                if(temp==X)
                {
                    return 1;
                }
                else if(temp>X)
                {
                    j=j-1;
                    temp=mat[i][j];
                }
                else
                {
                    i=i+1;
                    temp=mat[i][j];
                }
            }
       }
      catch(ArrayIndexOutOfBoundsException e) 
       {
           return 0;
       }
    }
}
