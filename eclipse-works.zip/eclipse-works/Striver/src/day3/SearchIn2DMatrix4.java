package day3;

import java.util.Scanner;

public class SearchIn2DMatrix4 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		int key=sc.nextInt();
		int matrix[][]=new int[n][m];

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(search(matrix, n,m,key)); 
	}
	public static boolean search(int mat[][],int n,int m,int key)
	{
		
		return binarySearch(mat,key,0,(m*n)-1,m);
		
	}
	public static boolean binarySearch(int array[][], int element, int low, int high,int column) {
		
		while (low <= high) {
			
			int mid = low + (high - low) / 2;
			System.out.println(low+" "+mid+" "+high);
			if (array[mid/column][mid%column] == element)
				return true;

			if (array[mid/column][mid%column] < element)
				low = mid + 1;

			else
				high = mid - 1;
		}
		return false;
	}
}
