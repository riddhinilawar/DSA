package day3;

//tc:O(nlogn) sc:O(1)
import java.util.*;

public class MajorityElementsNby3Times3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		if(arr.length==2)
		{
			HashSet<Integer> s= new HashSet<Integer>();
			s.add(arr[0]);
			s.add(arr[1]);
			System.out.println(s);
			return;
		}
		Arrays.sort(arr);
		HashSet<Integer> set= new HashSet<Integer>();
		int count=1;
		for(int i=1;i<arr.length;i++)
		{
			if(arr[i]==arr[i-1])
			{
				System.out.println("in");
				count++;
				if(count>(arr.length/2))set.add(arr[i]);
			}
			else
				count=1;
		}
		System.out.println(set);
	}
}
