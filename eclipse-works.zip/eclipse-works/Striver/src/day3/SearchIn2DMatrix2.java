package day3;

import java.util.Scanner;

public class SearchIn2DMatrix2 {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		int key=sc.nextInt();
		int matrix[][]=new int[n][m];

		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		System.out.println(search(matrix, n,m,key)); 
	}
	public static boolean search(int mat[][],int n,int m,int key)
	{
		boolean ans=false;
		for(int i=0;i<n;i++)
		{
			boolean temp=binarySearch(mat[i],key,0,mat[i].length-1);
			ans=ans||temp;
		}
		return ans;
	}
	public static boolean binarySearch(int array[], int element, int low, int high) {
		
		while (low <= high) {

			int mid = low + (high - low) / 2;

			if (array[mid] == element)
				return true;

			if (array[mid] < element)
				low = mid + 1;

			else
				high = mid - 1;
		}

		return false;
	}
}
