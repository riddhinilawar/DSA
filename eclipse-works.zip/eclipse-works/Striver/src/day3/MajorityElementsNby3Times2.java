package day3;
//tc:O(n) sc:O(n)
import java.util.*;
//tc:O(nsquare) sc:O(1)
import java.util.Scanner;

public class MajorityElementsNby3Times2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		ArrayList<Integer> a=new ArrayList<Integer>();
		int n=arr.length;
		for(int i=0;i<n;i++)
		{
			map.put(arr[i], map.getOrDefault(arr[i], 0)+1);
		}
		for(int i:map.keySet())
		{
			if(map.get(i)>(n/3))
			{
				a.add(i);
			}
		}
		System.out.println(a);
	}
}
