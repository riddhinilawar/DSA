package day3;
//application of merge sort
import java.util.*;

public class ReversePairs2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		int pair=0;
		int n=arr.length;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr[i]>arr[j])pair++;
			}
		}
		return pair;
	}
}
