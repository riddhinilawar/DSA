package day3;
//tc:O(nlogn) sc:O(n)
import java.util.*;

public class MajorityElementsNby2Times {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		int maxcount=arr.length/2;;
		HashMap<Integer,Integer> map=new HashMap<>();
		for(int i=0;i<arr.length;i++)
		{
			if(map.containsKey(arr[i])==true)
			{
				int temp=map.get(arr[i]);
				map.put(arr[i],temp+1 );
				if((temp+1)>maxcount)return arr[i];
			}
			else
			{
				map.put(arr[i], 1);
			}
		}
		return 0;
	}
}
