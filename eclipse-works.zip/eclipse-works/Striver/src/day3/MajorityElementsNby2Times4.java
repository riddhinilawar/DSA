package day3;
//tc:O(n) sc:O(1)
import java.util.*;

public class MajorityElementsNby2Times4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		if(arr.length==1)return arr[0];
        
        int element=0;
		int count=0;
		for(int i=0;i<arr.length;i++)
		{
			if(count==0)
			{
				element=arr[i];
                count=count+1;
			}
			else
			{
				if(arr[i]==element)
				{
					count=count+1;
				}
				else
				{
					count=count-1;
				}
			}
		}
		return element;
	}
}
