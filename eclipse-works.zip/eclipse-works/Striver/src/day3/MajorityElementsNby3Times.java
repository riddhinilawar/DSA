package day3;
import java.util.*;
//tc:O(nsquare) sc:O(1)
import java.util.Scanner;

public class MajorityElementsNby3Times {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		for(int i=0;i<arr.length;i++)
		{
			int count=0;
			for(int j=0;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				{
					count++;
				}
			}
			if(count>(arr.length/3))
			{
				if(!a.contains(arr[i]))
				a.add(arr[i]);
			}
		}
		System.out.println(a);
	}
}
