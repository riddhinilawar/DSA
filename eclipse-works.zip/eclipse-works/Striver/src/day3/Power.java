package day3;

import java.util.Scanner;

public class Power {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		double x=sc.nextDouble();
		int n=sc.nextInt();
		sc.close();
		System.out.println(pow(x,n));
	}
	public static double pow(double x,int n)
	{
		double ans=1.0;
		for(int i=0;i<n;i++)
		{
			ans=ans*x;
		}
		return ans;
	}
}
