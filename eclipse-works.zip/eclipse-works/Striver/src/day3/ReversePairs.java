package day3;
//TC:O(Nsquare)
//SC:O(1)
import java.util.*;

public class ReversePairs {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		int pair=0;
		int n=arr.length;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]>(2*arr[j]))pair++;
			}
		}
		return pair;
	}
}
