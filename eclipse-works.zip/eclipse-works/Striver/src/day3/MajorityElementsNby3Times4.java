package day3;
//tc:O(nsquare) sc:O(1)
//tc:O(n) sc:O(1)
//edge case: 1
//edge case : 1,2
import java.util.*;

public class MajorityElementsNby3Times4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		ArrayList<Integer> a=new ArrayList<Integer>();
		if(arr.length==2)
		{
			if(arr[0]==arr[1])
			{
				a.add(arr[0]);
				System.out.println(a);
				return;
			}
			else
			{
				a.add(arr[0]);
				a.add(arr[1]);
				System.out.println(a);
				return;
			}
			
		}
		int n=arr.length;
		int el1=-1,el2=-1,c1=0,c2=0;
		for(int i=0;i<n;i++)
		{
			if(el1==arr[i])
				{
					c1++;
					//System.out.println("In 1");
				}
			else if(el2==arr[i])
				{
					c2++;
					//System.out.println("In 2");
				}
			else if(c1==0)
				{
					el1=arr[i];
					c1++;
				}
			else if(c2==0)
				{
					el2=arr[i];
					c2++;
				}
			else 
			{
				c1--;
				c2--;
				//System.out.println("In 5");
			}
		}
		
		System.out.println(el1+" "+el2);
		int count1=0,count2=0;
		for(int i=0;i<n;i++)
		{
			if(arr[i]==el1)count1++;
			if(arr[i]==el2)count2++;
			if(count1>(n/3))
			{
				if(!a.contains(el1))a.add(el1);
			}
			if(count2>(n/3))
			{
				if(!a.contains(el2))a.add(el2);
			}
		}
		System.out.println(a);
		
	}
}
