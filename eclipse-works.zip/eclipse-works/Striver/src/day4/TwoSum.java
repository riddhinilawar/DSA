package day4;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class TwoSum {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int target=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr,target);
	}
	public static void fun(int arr[],int t)
	{
		int flag=0;
		
		int n=arr.length;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(arr[i]+arr[j]==t)
				{
					System.out.println("Pair Found "+arr[i]+" "+arr[j]);
					flag=1;
					break;
				}
			}
			if(flag==1)break;
		}
		if(flag==0)
		System.out.println("No pair found");
	}
}
