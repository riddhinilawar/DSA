package day4;

import java.util.*;
//test case
// 0 0
//3 3
public class TwoSum3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int target=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		
		int a[]=fun(arr,target);
		System.out.println(a[0]+" "+a[1]);
	}

	public static int[] fun(int arr[],int target)
	{
		int ans[]=new int[2];
		
		HashMap<Integer,Integer> map=new HashMap<>();
		
		for(int i=0;i<arr.length;i++)
		{
			if(map.containsKey(target-arr[i])==true)
			{
				//System.out.println(arr[i]+" "+(target-arr[i]));
				//System.out.println(i+" "+map.get(target-arr[i]));
				ans[0]=map.get(target-arr[i]);
				ans[1]=i;
				break;
			}
			else
			{
				map.put(arr[i], i);
			}
		}
		return ans;
	}
}