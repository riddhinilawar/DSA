package day4;
import java.util.*;
/*
 * [1000000000,1000000000,1000000000,1000000000]
-294967296*/
public class FourSum {
	 public static List<List<Integer>> fourSum(int[] nums, int target) {
	        HashSet<List<Integer>> set=new HashSet<>();
	        
	        int n=nums.length;
	        Arrays.sort(nums);
	        
	        for(int i=0;i<n;i++)
	        {
	            
	            for(int j=i+1;j<n;j++)
	            {
	                 for(int k=j+1;k<n;k++)
	                 {
	                
	                List<Integer> ll=new ArrayList<Integer>();
	                
	                int t=(target-nums[i]-nums[j]-nums[k]);
	                
	                
	                
	                if(t<=Integer.MAX_VALUE||t>=Integer.MIN_VALUE)
	                {
	                System.out.println(t+" "+target+" "+nums[i]+" "+nums[j]+" "+nums[k]);
	                if(BS(nums,k+1,n-1,t)==true)
	                {
	                    ll.add(nums[i]);
	                    ll.add(nums[j]);
	                    ll.add(nums[k]);
	                    ll.add(t);
	                    set.add(ll);
	                }
	                }
	                 }
	            }
	        }
	        
		     List<List<Integer>> ans= new ArrayList<>(set);
		        
		        return ans;
	     
	    }
	    public static boolean BS(int nums[],int start,int end,int target)
	    {
	        while(start<=end)
	        {
	             int mid=start+(end-start)/2;
	            
	             if(nums[mid]==target)return true;
	            
	             if(nums[mid]>target) return BS(nums,start,mid-1,target);
	             else return BS(nums,mid+1,end,target);
	        }
	        return false;
	    }
	    public static void main(String args[])
	    {
	    	//int arr[]= {-1,0,1,2,-1,-4};
	    	int arr[]= {1000000000,1000000000,1000000000,1000000000};
	    	System.out.println(fourSum(arr,-294967296));
	    }
}
