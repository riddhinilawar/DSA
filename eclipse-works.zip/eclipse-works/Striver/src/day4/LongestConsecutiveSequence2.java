package day4;
//exceptions if n==1,n==0
//tc:- O(nlogn) sc:O(1)
import java.util.*;
public class LongestConsecutiveSequence2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		Set<Integer> set=new HashSet<Integer>();
		for(int i=0;i<arr.length;i++)
		{
			set.add(arr[i]);
		}
		
		int maxcount=Integer.MIN_VALUE;
		int count=0;
		int currnum;
		for(int i:arr)
		{
			if(!set.contains(i-1))
			{
				System.out.println(i);
				count=1;
				currnum=i;
				
				while(set.contains(currnum+1))
				{
					currnum=currnum+1;
					count++;
				}
				maxcount=Math.max(maxcount, count);
			}
		}
		return maxcount;
	}
}
