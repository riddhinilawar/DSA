package day4;
//exceptions if n==1,n==0
//tc:- O(nlogn) sc:O(1)
import java.util.Arrays;
import java.util.Scanner;

public class LongestConsecutiveSequence {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(fun(arr));
	}
	public static int fun(int arr[])
	{
		Arrays.sort(arr);
		int maxcount=Integer.MIN_VALUE;
		int count=1;
		int curr=arr[0];
		
		for(int i=1;i<arr.length;i++)
		{
			if((arr[i]-1)==arr[i-1])
			{
				count++;
				maxcount=Math.max(maxcount, count);
			}
			else
			{
				curr=arr[i];
				count=1;
			}
		}
		return maxcount;
	}
}
