package day4;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
//test case
// 0 0
//3 3
public class TwoSum2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int target=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		//fun1(arr,target);
		int a[]=twoSum(arr,target);
		System.out.println(a[0]+" "+a[1]);
	}

	public static void fun(int arr[],int target)
	{
		int flag=0;
		Arrays.sort(arr);
		int start=0;
		int end=arr.length-1;
		while(start<end)
		{
			if(arr[start]+arr[end]==target)
			{
				System.out.println(arr[start]+" "+arr[end]);
				flag=1;
				break;
			}
			else if(arr[start]+arr[end]>target)
			{
				end--;
			}
			else
			{
				start++;
			}
		}
		if(flag==0)
			System.out.println("No pair found");
	}
	public static void fun1(int arr[],int target)
	{
		//function to get index rather than value

		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		for(int i=0;i<arr.length;i++)
		{
			if(map.containsKey(arr[i])==true)
			{
				map.put(-arr[i], i);
			}
			else
			{
				map.put(arr[i], i);
			}
		}
		int ans[]=new int[2];

		int flag=0;
		Arrays.sort(arr);
		int start=0;
		int end=arr.length-1;
		while(start<end)
		{
			if(arr[start]+arr[end]==target)
			{
				System.out.println(arr[start]+" "+arr[end]);
				ans[0]=arr[start];
				ans[1]=arr[end];

				flag=1;
				break;
			}
			else if(arr[start]+arr[end]>target)
			{
				end--;
			}
			else
			{
				start++;
			}
		}
		if(flag==0)
			System.out.println("No pair found");
		else
		{
			if(ans[0]!=ans[1])
			{
				System.out.println(map.get(arr[0])+" "+map.get(arr[1]));

				ans[0]=map.get(ans[0]);
				ans[1]=map.get(ans[1]);

				System.out.println("ans:"+ans[0]+" "+ans[1]);
			}
			else
			{
				System.out.println(map.get(arr[0])+" "+map.get(arr[1]));

				ans[0]=map.get(ans[0]);
				ans[1]=map.get(-ans[1]);

				System.out.println("ans:"+ans[0]+" "+ans[1]);
			}
		}
	}
	public static int[] twoSum(int[] nums, int target) {
		//function to get index rather than value
		int zero=0;
		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		for(int i=0;i<nums.length;i++)
		{
			if(map.containsKey(nums[i])==true)
			{
				if(nums[i]==0)
				{
					zero=i;
				}
				else
				{
					map.put(-nums[i], i);
				}
			}
			else
			{
				map.put(nums[i], i);
			}
		}
		int ans[]=new int[2];

		int flag=0;
		Arrays.sort(nums);
		int start=0;
		int end=nums.length-1;
		while(start<end)
		{
			if(nums[start]+nums[end]==target)
			{
				//System.out.println(nums[start]+" "+nums[end]);
				ans[0]=nums[start];
				ans[1]=nums[end];

				flag=1;
				break;
			}
			else if(nums[start]+nums[end]>target)
			{
				end--;
			}
			else
			{
				start++;
			}
		}
		if(flag==0)
			System.out.println("No pair found");
		else
		{
			if(ans[0]!=ans[1])
			{
				

				ans[0]=map.get(ans[0]);
				ans[1]=map.get(ans[1]);

				
			}
			else if(ans[0]==ans[1]&&ans[0]==0)
			{
				ans[0]=map.get(ans[0]);
				ans[1]=zero;
			}
			else
			{
				

				ans[0]=map.get(ans[0]);
				ans[1]=map.get(-ans[1]);

				
			}
		}
		return ans;
	}
}