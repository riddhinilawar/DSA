package day4;

public class subt {
	public static void main(String[] args) {
		long a=1000000000;
		long b=1000000000;
		long c=1000000000;
		long ans=a+b+c;
		System.out.println(ans);
	}
}
