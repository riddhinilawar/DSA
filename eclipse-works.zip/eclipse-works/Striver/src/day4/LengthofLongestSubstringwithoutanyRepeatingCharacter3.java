package day4;

import java.util.*;
import java.util.Set;

//Tc: O(n), sc:O(n)
public class LengthofLongestSubstringwithoutanyRepeatingCharacter3 {
	 public static int lengthOfLongestSubstring(String S) {
	        if(S.length()==0)return 0;
	        
	        int r=0,l=0;
	        int max_len=1;
	        
	        HashMap<Character,Integer> map=new HashMap<Character,Integer>();
	        
	        while(r<S.length()&&l<S.length())
	        {
	            if(map.containsKey(S.charAt(r))&&map.get(S.charAt(r))>=l)
	            {
	                l=map.get(S.charAt(r))+1;
	                map.put(S.charAt(r),r);
	            }
	            else
	            {
	                map.put(S.charAt(r),r);
	            }
	            
	            max_len=Math.max(max_len,r-l+1);
	           // System.out.println(max_len+" "+r);
	            r++;
	        }
	        return max_len;
	    }
	    public static void main(String args[]) {
	        String str = "takeUforwardriddhi";
	        System.out.println("The length of the longest substring without repeating characters is " + lengthOfLongestSubstring(str));

	    }
}
