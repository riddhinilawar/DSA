package day4;
import java.util.*;
//[0,0,0,0]
public class ThreeSum {
	 public static List<List<Integer>> threeSum(int[] nums) {
	        
         HashSet<List<Integer>> set=new HashSet<>();
        
        int n=nums.length;
        Arrays.sort(nums);
        
        for(int i=0;i<n;i++)
        {
            
            for(int j=i+1;j<n;j++)
            {
                
                List<Integer> ll=new ArrayList<Integer>();
                
                int target=(0-nums[i]-nums[j]);
                
                if(BS(nums,j+1,n-1,target)==true)
                {
                    ll.add(nums[i]);
                    ll.add(nums[j]);
                    ll.add(target);
                    set.add(ll);
                }
            }
        }
        
	     List<List<Integer>> ans= new ArrayList<>(set);
	        
	        return ans;
     
    }
    public static boolean BS(int nums[],int start,int end,int target)
    {
        while(start<=end)
        {
             int mid=start+(end-start)/2;
            
             if(nums[mid]==target)return true;
            
             if(nums[mid]>target) return BS(nums,start,mid-1,target);
             else return BS(nums,mid+1,end,target);
        }
        return false;
    }
	    public static void main(String args[])
	    {
	    	//int arr[]= {-1,0,1,2,-1,-4};
	    	int arr[]= {0,0,0,0};
	    	System.out.println(threeSum(arr));
	    }
}
