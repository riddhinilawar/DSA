package day1;

import java.util.*;

public class StockBuyAndSell2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)arr[i]=sc.nextInt();
		sc.close();
		System.out.println(stockBuySell(arr,arr.length));
		
		
	}

	public static int stockBuySell(int A[], int n) 
	{
		int maxpro=Integer.MIN_VALUE;
		int min=A[0];
		for(int i=1;i<n;i++)
		{
			if(A[i]<min)min=A[i];
			maxpro=Math.max(maxpro, A[i]-min);
		}
	    return maxpro;
	}

}
