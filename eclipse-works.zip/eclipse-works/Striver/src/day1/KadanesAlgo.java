package day1;

import java.util.Scanner;

public class KadanesAlgo {
	//for positive numbers only
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		
		int maxsum=Integer.MIN_VALUE;
		int sum=0;
		for(int i=0;i<n;i++)
		{
			sum=sum+arr[i];
			if(sum<0)sum=0;
			maxsum=Math.max(maxsum, sum);
		}
		System.out.println(maxsum);
	}
	/*For all integers
	 *  long maxSubarraySum(int arr[], int n){
        
        long maxsum=Integer.MIN_VALUE;
		long sum=0;
		int count=0;
		for(int i=0;i<n;i++)
		{   
		    
		    if(arr[i]<0)count++;
		    
			sum=sum+arr[i];
			if(sum<0)sum=0;
			maxsum=Math.max(maxsum, sum);
		}
		if(count==n)
		{maxsum=Integer.MIN_VALUE;
		for(int i=0;i<n;i++)
		{
		    	maxsum=Math.max(maxsum, arr[i]);
		}
		}
        return maxsum;
    }
	 */
}
