package day1;

import java.util.ArrayList;
import java.util.Scanner;

public class PascalsTriangle3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList<Long> ans=nthRowOfPascalTriangle(n);
		sc.close();
		System.out.println(ans);
	}
	public static ArrayList<Long> nthRowOfPascalTriangle(int n) {
	       
        ArrayList<Long> a=new ArrayList<Long>();
        
        int count=n;
        if(n==1)
        {
            a.add((long)1);
            return a;
        }
        if(n==2)
        {
            a.add((long)1);
            a.add((long)1);
            return a;
        }
        
        ArrayList<Long> prev=new ArrayList<Long>();
        prev.add((long)1);
        prev.add((long)1);
        
        int index=1;
        
        while(count-2!=0)
        {
            a=new ArrayList<Long>();
            a.add((long)1);
            for(int i=1;i<=index;i++)
            {
                long num=(((long)prev.get(i)+(long)prev.get(i-1))%1000000007);
                a.add(num);
            }
            a.add((long)1);
            
            
            count--;
            index++;
            
            prev=a;
            //System.out.println(prev);
        }
        return prev;
    }
}

