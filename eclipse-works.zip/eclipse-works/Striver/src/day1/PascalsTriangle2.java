package day1;
//leetcode 119 
import java.util.ArrayList;
import java.util.*;

public class PascalsTriangle2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		List<Integer> ans=getRow(n);
		sc.close();
		System.out.println(ans);
	}
	public static List<Integer> getRow(int n) {
        
        List<Integer> ans=new ArrayList<Integer>();
        if(n==0)
        {
            ans.add(1);
            return ans;
        }
        if(n==1)
        {
            ans.add(1);
            ans.add(1);
            return ans;
        }
        else
        {
            List<Integer> prev=new ArrayList<Integer>();
            prev.add(1);prev.add(1);
            
            for(int i=3;i<n+2;i++)
            {
                ans=new ArrayList<Integer>();
                for(int j=0;j<i;j++)
                {
                    if(j==0||j==i-1)
                    {
                        ans.add(1);
                    }
                    else
                    {
                        ans.add(prev.get(j-1)+prev.get(j));
                    }
                }
                prev=ans;
            }
        }
        return ans;
    }
}

