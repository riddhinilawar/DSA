package day1;

import java.util.ArrayList;
import java.util.Scanner;

public class PascalsTriangle {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		ArrayList<Long> ans=nthRowOfPascalTriangle(n);
		sc.close();
		System.out.println(ans);
	}
	public static ArrayList<Long> nthRowOfPascalTriangle(int n) {
		int numRows=n;
        if(numRows==0)
        {
            return new ArrayList<>();
        }
        ArrayList<ArrayList<Long>> res = new ArrayList<>();
        
        for(int i=1;i<=numRows;i++)
        {
            ArrayList<Long> row = new ArrayList<>();
            for(int j=0;j<i;j++)
            {
                if(j==0 || j==i-1) //first and last element of every row is always 1
                {
                     row.add((long)1);
                }
                else
                {
                    // adding jth and j-1th element of previous row
                    long num = (res.get(i-2).get(j)+res.get(i-2).get(j-1))%1000000007;
                    row.add(num);
                }
            }
            res.add(row);
        }
        return res.get(numRows-1);
    }
}

