package day1;
//TC:-O(2n)=O(n)
public class ArraySort012 {
	public static void main(String args[])
	{
		int arr[]= {0 ,2 ,1 ,2 ,0};
		sort012(arr,arr.length);
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	public static void sort012(int a[], int n)
	{
		int c0=0,c1=0,c2=0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]==0)c0++;
			if(a[i]==1)c1++;
			if(a[i]==2)c2++;
		}
		int i=0;
		while(c0!=0)
		{
			a[i]=0;
			i++;
			c0--;
		}
		while(c1!=0)
		{
			a[i]=1;
			i++;
			c1--;
		}
		while(c2!=0)
		{
			a[i]=2;
			i++;
			c2--;
		}
	}
}
