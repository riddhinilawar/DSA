package day1;

import java.util.Scanner;

public class StockBuyAndSell {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)arr[i]=sc.nextInt();
		sc.close();
		System.out.println(stockBuySell(arr,arr.length));
		
		
	}

	public static int stockBuySell(int A[], int n) 
	{
		int maxpro=Integer.MIN_VALUE;
		for(int i=0;i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				maxpro=Math.max(maxpro, A[i]-A[j]);
			}
		}
	    return maxpro;
	}
}
