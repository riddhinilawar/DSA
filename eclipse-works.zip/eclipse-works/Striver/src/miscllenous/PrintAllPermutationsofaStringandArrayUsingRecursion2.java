package miscllenous;

import java.util.Scanner;
//just printing all possible permutations.
public class PrintAllPermutationsofaStringandArrayUsingRecursion2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		permutation(arr,0);
	}
	public static void permutation(int arr[],int index)
	{
		if(index==arr.length)
		{
			//for printing
			for(int j=0;j<arr.length;j++)
			{
				System.out.print(arr[j]);
			}
			System.out.println();
			return;
		}
		for(int i=index;i<arr.length;i++)
		{
			swap(arr,i,index);
			permutation(arr,index+1);
			//backtracking
			swap(arr,i,index);
		}
	}
	public static void swap(int arr[],int i,int index)
	{
		int temp=arr[i];
		arr[i]=arr[index];
		arr[index]=temp;
	}
}