package miscllenous;

import java.util.*;
//returning all possible permutations.
public class PrintAllPermutationsofaStringandArrayUsingRecursion {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		ArrayList<ArrayList<Integer>> list=new ArrayList<>();
		permutation(arr,0,list);
		System.out.println(list);
	}
	public static void permutation(int arr[],int index,ArrayList<ArrayList<Integer>>  list)
	{
		if(index==arr.length)
		{
			//for answer in list
			ArrayList<Integer> temp=new ArrayList<>();
			for(int j=0;j<arr.length;j++)
			{
				temp.add(arr[j]);
			}
			list.add(temp);
			return;
		}
		for(int i=index;i<arr.length;i++)
		{
			swap(arr,i,index);
			permutation(arr,index+1,list);
			//backtracking
			swap(arr,i,index);
		}
	}
	public static void swap(int arr[],int i,int index)
	{
		int temp=arr[i];
		arr[i]=arr[index];
		arr[index]=temp;
	}
}
