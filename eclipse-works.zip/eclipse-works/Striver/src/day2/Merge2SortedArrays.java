package day2;

import java.util.Scanner;

/*n = 4, arr1[] = [1 3 5 7] 
m = 5, arr2[] = [0 2 6 8 9]*/
public class Merge2SortedArrays {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		long arr1[]=new long[n];
		for(int i=0;i<n;i++)
		{
			arr1[i]=sc.nextInt();
		}
		long arr2[]=new long[m];
		for(int i=0;i<m;i++)
		{
			arr2[i]=sc.nextInt();
		}
		sc.close();
		merge(arr1,arr2,n,m);
	}
	public static void merge(long arr1[], long arr2[], int n, int m) 
	{
		long arr3[]=new long[arr1.length+arr2.length];
		int i=0;
		int a1=0;
		int a2=0;
		while(a1!=arr1.length&&a2!=arr2.length)
		{
			if(arr1[a1]<=arr2[a2])
			{
				arr3[i]=arr1[a1];
				a1++;
				i++;
			}
			else
			{
				arr3[i]=arr2[a2];
				a2++;
				i++;
			}
		}
		while(a1!=arr1.length)
		{
			arr3[i]=arr1[a1];
			a1++;
			i++;
		}
		while(a2!=arr2.length)
		{
			arr3[i]=arr2[a2];
			a2++;
			i++;
		}
		for(int k=0;k<n+m;k++)
		{
			System.out.print(arr3[k]+" ");		
		}
	}
}