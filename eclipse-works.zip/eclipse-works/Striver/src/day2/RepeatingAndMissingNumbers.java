package day2;

import java.util.Scanner;

public class RepeatingAndMissingNumbers {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		int dup=0,miss=0;
		int temp[]=new int[arr.length+1];
		for(int i=0;i<arr.length;i++)
		{
			temp[arr[i]]++;
		}
		for(int i=1;i<temp.length;i++)
		{
			if(temp[i]==0)
			{
				miss=i;
			}
			if(temp[i]==2)
			{
				dup=i;
			}
		}
		System.out.println("dup: "+dup+" miss:"+miss);
	}
}
