package day2;

import java.util.Scanner;

/*n = 4, arr1[] = [1 3 5 7] 
m = 5, arr2[] = [0 2 6 8 9]*/
public class Merge2SortedArrays3 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		long arr1[]=new long[n];
		for(int i=0;i<n;i++)
		{
			arr1[i]=sc.nextInt();
		}
		long arr2[]=new long[m];
		for(int i=0;i<m;i++)
		{
			arr2[i]=sc.nextInt();
		}
		sc.close();
		merge(arr1,arr2,n,m);
	}

	public static void merge(long arr1[], long arr2[], int n, int m) 
	{
		int gap =(int) Math.ceil((double)(n + m) / 2.0);
		
		while(gap>0)
		{
			
			int p1=0;
			int p2=gap;
			System.out.println(p1+" "+p2);
			while(p2<(n+m))
			{
				
				if(p2<n&&arr1[p1]>arr1[p2])
				{
					long temp=arr1[p1];
					arr1[p1]=arr1[p2];
					arr1[p2]=temp;
				}
				else if(p2>=n&&p1<n&&arr1[p1]>arr2[p2-n])
				{
					long temp=arr1[p1];
					arr1[p1]=arr2[p2-n];
					arr2[p2-n]=temp;
				}
				else if(p2>=n&&p1>=n&&arr2[p1-n]>arr2[p2-n])
				{
					long temp=arr2[p1-n];
					arr2[p1-n]=arr2[p2-n];
					arr2[p2-n]=temp;
				}
				p1++;
				p2++;
			}
			
			if (gap == 1) {
			      gap = 0;
			    } else {
			    	gap =(int) Math.ceil((double) gap / 2.0);
			    }
			
			for(int k=0;k<n;k++)
			{
				System.out.print(arr1[k]+" ");		
			}
			System.out.println();
			for(int k=0;k<m;k++)
			{
				System.out.print(arr2[k]+" ");		
			}
			System.out.println();
		}
		
		
		for(int k=0;k<n;k++)
		{
			System.out.print(arr1[k]+" ");		
		}
		System.out.println();
		for(int k=0;k<m;k++)
		{
			System.out.print(arr2[k]+" ");		
		}
	}
}