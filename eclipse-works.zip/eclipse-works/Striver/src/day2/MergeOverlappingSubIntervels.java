package day2;
import java.util.*;
//4
//1 3 2 4 6 8 9 10
/*Intervals = {{6,8},{1,9},{2,4},{4,7}}
Output: {{1, 9}}*/
public class MergeOverlappingSubIntervels {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[][]=new int[n][2];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<2;j++)
			{
				arr[i][j]=sc.nextInt();
			}
		}
		sc.close();
		int res[][]=overlappedInterval(arr);
		for(int i=0;i<res.length;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(res[i][j]);
			}
			System.out.println();
		}
	}
	public static int[][] overlappedInterval(int[][] Intervals)
    {
       
        Stack<int[]> stack = new Stack<>();
        
        Arrays.sort(Intervals, (a, b) -> {return a[0] - b[0];});       
        
        stack.push(Intervals[0]);
        
        for(int i = 1; i < Intervals.length; i++){
            int[] top = stack.peek();
            if(Intervals[i][0] > top[1]) stack.push(Intervals[i]);
            else{
                top[1] = Math.max(Intervals[i][1], top[1]);
                stack.pop();
                stack.push(top);
            }
        }
        
        
        int[][] result = new int[stack.size()][2];
        int i = stack.size() -1;
        
        while(!stack.isEmpty()){
            result[i--] = stack.pop();
        }
        
        return result;
    }
}
