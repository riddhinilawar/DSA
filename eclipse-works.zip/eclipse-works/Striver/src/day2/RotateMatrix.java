package day2;

import java.util.Scanner;

public class RotateMatrix {
	public static void main(String args[])
	{
		//taking inputs
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		
		int matrix[][]=new int[n][n];
		
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				matrix[i][j]=sc.nextInt();
			}
		}
		sc.close();
		rotateby90(matrix, n); 
	}
	public static void rotateby90(int matrix[][], int n) 
	    { 
	        int a[][]=new int[n][n];
	        for(int i=0;i<n;i++)
	        {
	            for(int j=0;j<n;j++)
	            {
	                a[i][j]=matrix[j][n-i-1];
	                //System.out.println("a= i:"+i+" j:"+j+" mat= i:"+j+" j:"+(n-1-i) );
	            }
	        }
	        for(int i=0;i<n;i++)
	        {
	            for(int j=0;j<n;j++)
	            {
	                System.out.print(a[i][j]+" ");
	            }
	            System.out.println();
	        }
	    }
}
