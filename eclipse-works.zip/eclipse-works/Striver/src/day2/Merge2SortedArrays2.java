package day2;

import java.util.Scanner;

/*n = 4, arr1[] = [1 3 5 7] 
m = 5, arr2[] = [0 2 6 8 9]*/
public class Merge2SortedArrays2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int m=sc.nextInt();
		long arr1[]=new long[n];
		for(int i=0;i<n;i++)
		{
			arr1[i]=sc.nextInt();
		}
		long arr2[]=new long[m];
		for(int i=0;i<m;i++)
		{
			arr2[i]=sc.nextInt();
		}
		sc.close();
		merge(arr1,arr2,n,m);
	}
	public static void merge(long arr1[], long arr2[], int n, int m) 
	{
		
		for(int i=0;i<n;i++)
		{
			if(arr1[i]>arr2[0])
			{
				long temp=arr1[i];
				arr1[i]=arr2[0];
				arr2[0]=temp;
			}
			
			
			int j=0;
			long first=arr2[0];
			for(j=1;j<m&&arr2[j]<first;j++)
			{
				arr2[j-1]=arr2[j];
			}
			arr2[j-1]=first;
			
		}
		
		for(int k=0;k<n;k++)
		{
			System.out.print(arr1[k]+" ");		
		}
		System.out.println();
		for(int k=0;k<m;k++)
		{
			System.out.print(arr2[k]+" ");		
		}
	}
}