package day2;

import java.util.Scanner;

public class RepeatingAndMissingNumbers2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		fun(arr);
	}
	public static void fun(int arr[])
	{
		//normal
		int s=0;
		for(int i=0;i<arr.length;i++)
		{
			s=s+arr[i];
		}
		int ssquare=0;
		for(int i=0;i<arr.length;i++)
		{
			ssquare=ssquare+(arr[i]*arr[i]);
		}
		
		//formula
		int n=arr.length;
		int fs=n*(n+1);
		fs=fs/2;
		int fssquare=n*(n+1)*((2*n)+1);
		fssquare=fssquare/6;
		
		
		int diff=s-fs;
		int diffsquare=ssquare-fssquare;
		diffsquare=diffsquare/diff;
		
		int miss=(diff+diffsquare)/2;
		int dup=diffsquare-miss;
		
		System.out.println(miss+" --miss "+dup+" -- duplicate");
	}
}
