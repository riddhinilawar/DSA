package day2;
//TC:O(N) SC:O(N)
import java.util.Arrays;
import java.util.Scanner;

public class FindTheDuplicateInAArray2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		fun(arr);
		sc.close();
	}
	public static void fun(int arr[])
	{
		int temp[]=new int[arr.length+1];
		for(int i=0;i<arr.length;i++)
		{
			if(temp[arr[i]]==1)
			{
				System.out.println(temp[arr[i]]+"--is duplicate element");
				break;
			}
			else
			temp[arr[i]]++;
		}
	}
}
