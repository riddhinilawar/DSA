package day2;
//application of merge sort
import java.util.*;

public class InversionOfArray2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(mergeSort(arr,0,arr.length-1));
	}
	public static int mergeSort(int arr[], int l, int r)
	{    
		int count=0;
		if(l<r)
		{
		int mid=l+(r-l)/2;
		count+=mergeSort(arr,l,mid);
		count+=mergeSort(arr,mid+1,r);
		count+=merge(arr,l,mid,r);
		}
		return count;
	}
	public static int merge(int arr[], int start, int mid, int end)
	{
		int c=0;
		int index1=start;
		int index2=mid+1;
		int a[]=new int[end-start+1];
		int i=0;
		while(index1<=mid&&index2<=end)
		{
			if(arr[index1]<=arr[index2])
			{
				a[i]=arr[index1];
				i++;
				index1++;
			}
			else
			{
				a[i]=arr[index2];
				i++;
				index2++;
				c=c+(mid-index1);
			}

		}
		while(index1<=mid)
		{
			a[i]=arr[index1];
			i++;
			index1++;
		}
		while(index2<=end)
		{
			a[i]=arr[index2];
			i++;
			index2++;
		}
		for(int k=0,j=start;k<a.length;k++,j++)
		{
			arr[j]=a[k];
		}
		return c;
	}
}
