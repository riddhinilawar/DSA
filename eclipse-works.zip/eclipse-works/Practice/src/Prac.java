
public class Prac {
	int arr[]=new int[5];
	int index=-1;
	
	private void push(int num) {
		if(index==arr.length-1) {
			System.out.println("Stack Overflow");
		}
		else {
			index++;
			arr[index]=num;
			System.out.println(num+" inserted");
		}
	}
	private int peek() {
		if(index==-1) {
			System.out.println("Stack Underfow");
			return -1;
		}
		else return arr[index];
	}
	private int pop() {
		if(index==-1) {
			System.out.println("Stack Underfow");
			return -1;
		}
		else {
			int temp= arr[index];
			index--;
			return temp;
		}
	}
	public static void main(String[] args) {
		Prac obj = new Prac();
		obj.push(6);
		System.out.println(obj.peek());
		obj.push(4);
		obj.push(3);
		obj.push(2);
		obj.push(1);
		obj.push(0);
		obj.push(-1);
		System.out.println(obj.pop());
		System.out.println(obj.peek());
		System.out.println(obj.pop());
		System.out.println(obj.pop());
		System.out.println(obj.pop());
		obj.push(5);
		System.out.println(obj.pop());
		
	}
}
