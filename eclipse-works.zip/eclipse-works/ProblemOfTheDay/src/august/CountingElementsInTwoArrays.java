package august;

import java.util.*;

public class CountingElementsInTwoArrays {
	public static void main(String args[])
	{
		//input
		Scanner sc=new Scanner(System.in);
		int m=sc.nextInt();
		int n=sc.nextInt();
		int arr1[]=new int[m];
		for(int i=0;i<m;i++)
		{
			arr1[i]=sc.nextInt();
		}
		int arr2[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr2[i]=sc.nextInt();
		}
		sc.close();
		Arrays.sort(arr2);
		ArrayList<Integer> a=new ArrayList<Integer>();
		//logic
		for(int i=0;i<m;i++)
		{
			System.out.println(binarySearch(arr2,arr1[i]));
		}
		//output printing
	}
	public static int binarySearch(int arr[],int key)
	{
		int i=0,j=arr.length-1;
        int ans=-1;
        
        while(i<=j){
            int mid=i+(j-i)/2;
            if(arr[mid]<=key){
                ans=mid;
                i=mid+1;
            }else{
                j=mid-1;
            }
        }
        return ans;
	}
}
