package august;

import java.util.Scanner;
//Expected Time Complexity: O(N) Expected Auxiliary Space: O(N)
public class AlternatePositiveAndNegativeNumbers {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)arr[i]=sc.nextInt();
		sc.close();
		rearrange(arr,arr.length);
		for(int i=0;i<n;i++)System.out.println(arr[i]+" ");
		
	}
	public static int[] rearrange(int arr[], int n) {
        int a[]=new int[n];
        
        int j=n-1;
        int i=0;
        
        for(int k=0;k<n;k++)
        {
            if(arr[k]>=0)
            {
                a[i]=arr[k];
                i++;
            }
            else
            {
                a[j]=arr[k];
                j--;
            }
        }
        
        
        
        int icount=i;
        int jcount=n-j-1;
        
        //System.out.println(icount+" "+jcount);
        
        
        i=0;
        j=n-1;
        //System.out.println(jcount);
        for(int k=0;k<n;k++)
        {
            if(icount>0&&jcount>0)
            {
                
            if(k%2==0)
            {
                arr[k]=a[i];
                i++;
                icount--;
            }
            else
            {
                arr[k]=a[j];
                j--;
                jcount--;
            }
            }
            else if(icount>0)
            {
                arr[k]=a[i];
                i++;
                icount--;
            }
            else if(jcount>0)
            {
                arr[k]=a[j];
                j--;
                jcount--;
            }
        }
        return arr;
    }
}
