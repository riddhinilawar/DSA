package august;

import java.util.Scanner;
//tc: O(n), sc:O(1)
//edge cases: 1 2 3 6 8
//edge cases: 0 1 4 5 2
public class SmallestSumContigeousSubArray {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)arr[i]=sc.nextInt();
		sc.close();
		System.out.println(smallestSumSubarray(arr,arr.length));
		
		
	}
	 static int smallestSumSubarray(int a[], int size)
	    {
	        int count=0;
	        int posans=Integer.MAX_VALUE;
	        int n=a.length;
	        int sum=0;
	        int minsum=Integer.MAX_VALUE;
	        for(int i=0;i<n;i++)
	        {
	            sum=sum+a[i];
	            if(sum>=0)
	            {
	                sum=0;
	            }
	            else
	            {
	                minsum=Math.min(minsum,sum);
	            }
	            
	            //handling exception
	            if(a[i]>=0)
	            {
	                count++;
	                posans=Math.min(posans,a[i]);
	            }
	        }
	        if(count==n)
	        return posans;
	        else
	        return minsum;
	    }
}
