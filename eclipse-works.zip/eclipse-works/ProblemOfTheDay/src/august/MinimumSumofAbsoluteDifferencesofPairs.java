package august;

import java.util.*;

public class MinimumSumofAbsoluteDifferencesofPairs {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int A[]=new int[n];
		int B[]=new int[n];
		for(int i=0;i<n;i++)
		{
			A[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			B[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(findMinSum(A,B,n));
	}
	public static long findMinSum(int[] A,int[] B,int N) { 
        Arrays.sort(A);
        Arrays.sort(B);
        long sum=0;
        for(int i=0;i<N;i++)
        {
            long temp=A[i]-B[i];
            if(temp>0)
            {
                sum=sum+temp;
            }
            else
            {
                temp=-temp;
                sum=sum+temp;
            }
        }
        return sum;
    }
}
