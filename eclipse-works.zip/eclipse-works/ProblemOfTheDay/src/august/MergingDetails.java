package august;
import java.util.*;
public class MergingDetails {
	public static void main(String args[])
	{
	
	}
	public List<List<String>> mergeDetails(List<List<String>> details) {
//        LinkedHashMap<String, List<String>> map = new LinkedHashMap<String, List<String>>();
//        
//        for(List<String> l:details)
//        {
//            if(map.containsKey(l.get(0)))
//            {
//            	List<String> temp=map.get(l.get(0));
//            	map.merge(l.get(0), l,temp );
//            	map.put(l.get(0),l);
//            }
//            else
//            {
//            	Collections.sort(l);
//            	map.put(l.get(0),l);
//            }
//        }
//        
//        List<String> values = map.values();
        
        return details;
    }
}
