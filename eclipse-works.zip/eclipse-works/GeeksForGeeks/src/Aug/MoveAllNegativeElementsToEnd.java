package Aug;

import java.util.Scanner;

public class MoveAllNegativeElementsToEnd {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		segregateElements(arr,arr.length);
	}
	public static void segregateElements(int arr[], int n)
    {
        int neg[]=new int[n];
        int idx=0;
        int curr=0;
        for(int i=0;i<n;i++)
        {
            if(arr[i]>0)
            {
                arr[curr]=arr[i];
                curr++;
            }
            else
            {
                neg[idx]=arr[i];
                idx++;
                
            }
        }
        for(int i=curr,j=0;j<idx;j++,i++)
        {
            arr[i]=neg[j];
        }
    }

}
