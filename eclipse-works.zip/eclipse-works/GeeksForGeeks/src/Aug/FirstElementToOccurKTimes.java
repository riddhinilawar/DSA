package Aug;

import java.util.*;
/*
 * Exceptional test case
 * 3 1
 * 3 1 2
 */
public class FirstElementToOccurKTimes {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int target=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		System.out.println(firstElementKTime(arr,arr.length,target));
	}
	 public static int firstElementKTime(int[] a, int n, int k) { 
	        if(k==1)return a[0];
	        HashMap<Integer,Integer>map=new HashMap<Integer,Integer>();
	        for(int i=0;i<n;i++)
	        {
	            if(map.size()!=0&&map.containsKey(a[i])==true)
	            {
	                if(map.get(a[i])+1==k)return a[i];
	                map.put(a[i],map.get(a[i])+1);
	            }
	            else
	            {
	                map.put(a[i],1);
	            }
	        }
	        return -1;
	    } 
}
