package Aug;

import java.util.*;

public class SumPermutation {
	public static void main(String args[]) {
		int A[]= {1,2};
		if(A.length<2) 
		{
			System.out.println("1");
		}
		List<Long> ans=new ArrayList<Long>();
		permutations(A,0,ans);
		
		long answer=0;
		for(long i:ans)
		{
			answer=answer+i;
		}
		System.out.println(ans+" "+answer);
	}
	public static void permutations(int arr[],int index, List<Long> ans)
	{
		if(index==arr.length)
		{
			long temp=0;
			for(int i=0;i<arr.length;i++)
			{
				temp=(temp*10)+(int)arr[i];
			}
			ans.add(temp);
			return;
		}
		for(int i=index;i<arr.length;i++)
		{
			swap(arr,i,index);
			permutations(arr,index+1,ans);
			swap(arr,i,index);
		}
	}
	public static void swap(int arr[],int i,int j)
	{
		int temp=arr[i];
		arr[i]=arr[j];
		arr[j]=temp;
	}
}




