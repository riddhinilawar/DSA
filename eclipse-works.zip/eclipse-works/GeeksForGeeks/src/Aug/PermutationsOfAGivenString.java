package Aug;
import java.util.*;
public class PermutationsOfAGivenString {
	public static void main(String args[]) {
		String S="ABC";
        char arr[]=S.toCharArray();
        List<String> list=new ArrayList<String>();
        permutations(arr,0,list);
        Collections.sort(list);
        System.out.println(list);
    }
    public static void permutations(char arr[],int index,List<String> ans)
    {
        if(index==arr.length)
        {
            String temp="";
            for(int i=0;i<arr.length;i++)
            {
                temp=temp+arr[i];
            }
            ans.add(temp);
            return;
        }
        for(int i=index;i<arr.length;i++)
        {
            swap(arr,i,index);
            permutations(arr,index+1,ans);
            swap(arr,i,index);
        }
    }
    public static void swap(char arr[],int i,int j)
    {
        char temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }
}
