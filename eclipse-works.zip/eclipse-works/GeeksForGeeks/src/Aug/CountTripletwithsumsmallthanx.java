package Aug;

import java.util.Arrays;

public class CountTripletwithsumsmallthanx {
	 public static long countTriplets(long arr[], int n,int sum)
	    {
		 	Arrays.sort(arr);
	        long count=0;
	        for(int i=0;i<n-2;i++)
	        {
	            int j=i+1;
	            int k=n-1;
	            
	            System.out.println(i);
	            
	            while(j<k)
	            {
	            	System.out.println(arr[i]+" "+arr[j]+" "+arr[k]+" "+count);
	            	
	                if(arr[i]+arr[j]+arr[k]<sum)
	                {
	                	count=count+(k-j);
	                	j++;
	                }
	                else 
	                {
	                    k--;
	                }
	                
	            }
	        }
	        return count;
	    }
	 public static void main(String args[])
	 {
		 long arr[]= {5,1,3,4,7};
		 System.out.println(countTriplets(arr,arr.length,12));
	 }
}
