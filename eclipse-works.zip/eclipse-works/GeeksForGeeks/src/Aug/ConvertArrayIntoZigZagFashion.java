package Aug;

import java.util.Scanner;

public class ConvertArrayIntoZigZagFashion {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		sc.close();
		zigZag(arr,arr.length);
		for(int i=0;i<n;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	public static void zigZag(int arr[], int n) {
		boolean flag=true; 
		for(int i=0;i<n-1;i++)
		{
			if(flag==true)
			{
				if(arr[i]>arr[i+1])
				{
					int temp=arr[i];
					arr[i]=arr[i+1];
					arr[i+1]=temp;
				}
				flag=false;
			}
			else
			{
				if(arr[i]<arr[i+1])
				{
					int temp=arr[i];
					arr[i]=arr[i+1];
					arr[i+1]=temp;
				}
				flag=true;
			}
		}
	}
}
